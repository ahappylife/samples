﻿using System;
using System.Windows.Forms;

/*Pease add the windows.Forms dll to the project*/

namespace Finalcasestudy
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       
    }
}