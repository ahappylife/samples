﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Finalcasestudy
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";
        protected void Page_Load(object sender, EventArgs e)
        {

           

        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string command = "Select UserName from tblInsuranceAgents where UserName= '" + txtusername.Text.Trim() + "' ";
                SqlCommand cmd;
                cmd = new SqlCommand(command, con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (dr.HasRows)
                {
                    Response.Write("<script>alert('Username you have entered already exists.Please enter another username!')</script>");
                    cmd.Cancel();
                }

                else
                {
                   command = "Insert into tblInsuranceAgents(@Agent_Id,@FullName,@UserName,@Password,@ConfirmPassword,@Email,@Address,@Gender)";
                    SqlCommand insertagents = new SqlCommand(command, con);
                    insertagents.Parameters.AddWithValue("@Agent_Id", tbxAgentId.Text);
                    insertagents.Parameters.AddWithValue("@FullName", txtname.Text);
                    insertagents.Parameters.AddWithValue("@UserName", txtusername.Text);
                    insertagents.Parameters.AddWithValue("@Password", txtpassword.Text);
                    insertagents.Parameters.AddWithValue("@ConfirmPassword", txtconfirmpassword.Text);
                    insertagents.Parameters.AddWithValue("@Email", txtmail.Text);
                    insertagents.Parameters.AddWithValue("@Address", txtAddress.Text);
                    if (rdMale.Checked == true)
                    {
                        insertagents.Parameters.AddWithValue("@Gender", rdMale.Text);
                    }
                    else if (rdfemale.Checked == true)
                    {
                        insertagents.Parameters.AddWithValue("@Gender", rdfemale.Text);
                    }
                    insertagents.ExecuteNonQuery();
                    Response.Redirect("~/FirstPagee.aspx");
                    Response.Write("<script>alert('You have successfully created your account!')</script>");
                }
            }
        }
    }
}

//string command = "Insert into tblInsuranceAgents (@Agent_Id,@FullName,@UserName,@Password,@ConfirmPassword,@Email,@Address,@Gender)";
//using (SqlCommand cmd = new SqlCommand(command,con))
//{
//    cmd.Parameters.AddWithValue("@Agent_Id",tbxAgentId.Text);
//    cmd.Parameters.AddWithValue("@FullName",txtname.Text);

//    cmd.Parameters.AddWithValue("@UserName", txtusername.Text);
//    cmd.Parameters.AddWithValue("@Password", txtpassword.Text);
//    cmd.Parameters.AddWithValue("@ConfirmPassword", txtconfirmpassword.Text);
//    cmd.Parameters.AddWithValue("@Email", txtmail.Text);
//    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
//    if (rdMale.Checked == true)
//    {
//        cmd.Parameters.AddWithValue("@Gender", rdMale.Text);
//    }
//    else
//    {
//        cmd.Parameters.AddWithValue("@Gender", rdfemale.Text);
//    }
//    cmd.ExecuteNonQuery();
//    Response.Redirect("~/FirstPagee.aspx");
//    Response.Write("<script>alert('You have successfully created your account!')</script>");
//}