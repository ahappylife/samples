﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication13
{
    delegate int MyDelegate(int i, int j);
    class Program

    {
        static void Main(string[] args)
        {
            MyDelegate del = (i, j) => i + j;
            var result = del(6, 9);
            Console.WriteLine("the result is {0}", result);
            Console.ReadKey();
        }
    }
    
}

