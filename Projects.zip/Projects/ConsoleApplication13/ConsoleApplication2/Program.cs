﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{

    public class GenericArray<T>
    {

    }





    class Program
    {
        static void Main(string[] args)
        {
            GenericArray<int> intarray = new GenericArray<int>(5);
            for(int c=0;c<5;c++)
            {
                intarray.setItem(c, c);

            }
            for (int c=0;c<5;c++)
            {
                Console.WriteLine(intarray.getItem(c));
            }



            GenericArray<int> chararray = new GenericArray<int>(5);
            for (int c = 0; c < 5; c++)
            {
               chararray.setItem(c, c);

            }
            for (int c = 0; c < 5; c++)
            {
                Console.WriteLine(chararray.getItem(c));
            }
        }
    }





}
