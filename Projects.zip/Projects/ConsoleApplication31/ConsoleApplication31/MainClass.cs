﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement
{​
class Program
    {
        private static object add;
        static void Main(string[] args)
        {
            char ch;
            do
            {

                Console.WriteLine("Product Implementation");
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. Remove Product");
                Console.WriteLine("3. Modify Product");

                Console.WriteLine("Enter Your Choice:");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        add.AddProduct();
                        break;
                    case 2:
                        add.RemoveProduct();
                        break;
                    case 3:
                        add.ModifyProduct();
                        break;

                    default:
                        Console.WriteLine("Wrong selection! Select from 1 to 3 Only");
                        break;
                }
                Console.WriteLine("To continue select Y or N");
                ch = Convert.ToChar(Console.ReadLine());
            } while ((ch == 'y') || (ch == 'Y'));
            Console.ReadKey();
        }
    }
}
