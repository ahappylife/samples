﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement
{
    class ProductOnSale : Product
    {
        public int QuantityOnSale { get; set; }
        public List<int> BatchID { get; set; }

        public ProductOnSale()
        {
            QuantityOnSale = 0;
            BatchID = null;
        }

    }
}
