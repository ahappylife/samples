﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement
{
    class ProductOnDiscount : Product
    {
        public float DiscountPercentage { get; set; }
        public int MinimumPickQuantity { get; set; }

        public ProductOnDiscount()
        {
            DiscountPercentage = 0;
            MinimumPickQuantity = 0;
        }


        public void CopyAProduct(int PCode)
        {
            List<Product> CopiedProductsList = new List<Product>();
            var prod = from p in List_Of_Products where p.ProductCode == PCode select p;
            CopiedProductsList.Add(prod.First());
            Console.WriteLine("Product Copied Successfully");
        }
    }
}
