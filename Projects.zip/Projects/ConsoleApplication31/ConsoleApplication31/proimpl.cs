﻿using System;

namespace FurnitureDealers
{
    internal class proimpl
    {
        internal void AddProduct()
        {
            throw new NotImplementedException();
        }

        internal void RemoveProduct()
        {
            throw new NotImplementedException();
        }

        internal void ModifyProduct()
        {
            throw new NotImplementedException();
        }
    }
}