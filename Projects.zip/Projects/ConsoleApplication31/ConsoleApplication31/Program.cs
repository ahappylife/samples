﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement
{
    interface IProduct
    {
        int GetProductCode(string PName);
        List<string> GetAllProductCodes();
        string GetProductDesc(int PCode);
        int GetCategoryCode(int pCode);
        float GetDiscountPercent(int pCode);
        float GetQuantityOnSale();
        int GetProductCode();
        float GetQuantityOnSale(int pCode);
    }

    class Product : IProduct
    {
        public int ProductCode { get; set; }
        public string ProductName { get; set; }
        public int CategoryCode { get; set; }
        public static int ProductCount { get; set; }
        public List<Product> List_Of_Products = new List<Product>();
        List<ProductOnDiscount> List_Of_ProductOnDiscount = new List<ProductOnDiscount>();
        List<ProductOnSale> List_Of_ProductOnSale = new List<ProductOnSale>();


        public Product()
        {
            ProductCode = 0;
            ProductName = "";
            CategoryCode = 0;
            Product.ProductCount = 0;
        }

        public void AddProduct()
        {
            Product product = new Product();
            Console.WriteLine("Enter the Product Code");
            product.ProductCode = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Product Name");
            product.ProductName = Console.ReadLine();
            Console.WriteLine("Enter the Category Code");
            product.CategoryCode = int.Parse(Console.ReadLine());
            List_Of_Products.Add(product);
        }

        public void RemoveProduct()
        {
            Console.WriteLine("Enter the product code of the product to be removed");
            int pCode = int.Parse(Console.ReadLine());
            var premove = from prod in List_Of_Products where prod.ProductCode == pCode select prod;
            List_Of_Products.Remove(premove.First());
        }

        public void ModifyProduct()
        {
            Console.WriteLine("Enter the product code of the product to be modified");
            int pCode = int.Parse(Console.ReadLine());
            var premove = from prod in List_Of_Products where prod.ProductCode == pCode select prod;
            Product newproduct = new Product();
            newproduct = premove.First();
            Console.WriteLine("Enter the new name of the product");
            newproduct.ProductName = Console.ReadLine();
            Console.WriteLine("Enter the new Category Code");
            newproduct.CategoryCode = int.Parse(Console.ReadLine());
            Console.WriteLine("Successfully Updated");
        }

        int IProduct.GetProductCode()
        {
            Console.WriteLine("Enter the name of the product whose code has to be found");
            string PName = Console.ReadLine();
            var prod = from p in List_Of_Products where p.ProductName == PName select p;
            return prod.First().ProductCode;
        }

        List<string> IProduct.GetAllProductCodes()
        {
            List<string> list_of_pcodes = new List<string>();
            var prod = from p in List_Of_Products select p;
            foreach (var item in prod)
            {
                list_of_pcodes.Add(item.ProductCode.ToString());
            }
            return list_of_pcodes;
        }

        string IProduct.GetProductDesc(int PCode)
        {
            throw new NotImplementedException();
        }

        int IProduct.GetCategoryCode(int pCode)
        {
            var prod = from p in List_Of_Products where p.CategoryCode == pCode select p;
            return prod.First().CategoryCode;
        }

        float IProduct.GetDiscountPercent(int pCode)
        {
            var prod = from p in List_Of_ProductOnDiscount where p.CategoryCode == pCode select p;
            return prod.First().DiscountPercentage;
        }

        float IProduct.GetQuantityOnSale(int pCode)
        {
            var prod = from p in List_Of_ProductOnSale where p.CategoryCode == pCode select p;
            return prod.First().QuantityOnSale;
        }

        public int GetProductCode(string PName)
        {
            throw new NotImplementedException();
        }

        public float GetQuantityOnSale()
        {
            throw new NotImplementedException();
        }
    }
}














