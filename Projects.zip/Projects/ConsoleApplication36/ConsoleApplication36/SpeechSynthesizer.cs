﻿using System;

namespace ADO.net1
{
    internal class SpeechSynthesizer
    {
        internal void Speak(string v)
        {
            throw new NotImplementedException();
        }
    }
}