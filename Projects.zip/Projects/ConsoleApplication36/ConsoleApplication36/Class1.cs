﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;


namespace ADO.net1
{
    class Program
    {

        //  static string conString = @"Server=INCHCMPC11363;Database=assignmentDatabase;Trusted_Connection=True;";
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder(@"Server=");
            Console.WriteLine("Please enter the server name");
            sb.Append(Console.ReadLine());
            sb.Append(";Database=");
            Console.WriteLine("Please enter the database name");
            sb.Append(Console.ReadLine());
            sb.Append(";Trusted_Connection=True;");
            Console.WriteLine(sb);
            //try
            //{
            //    SpeechSynthesizer speaker = new SpeechSynthesizer();
            //    speaker.Speak("Before inserting the data");
            //    Console.WriteLine("*****Before inserting the data*****");
            //    Display(sb);
            //    // InsertData(sb);
            //    speaker.Speak("After inserting the data");
            //    Console.WriteLine("******After inserting the data in to the sectors*****");
            //    //Display(sb);
            //    DeleteData(sb);
            //    speaker.Speak("After deleting  the data");
            //    Display(sb);
            //}
            //catch (Exception ex)
            //{

            //    Console.WriteLine(ex.Message);
            //    Console.ReadLine();
            //}
        }

        private static void DeleteData(StringBuilder sb)
        {
            Console.WriteLine("Please enter the tablename and condition for the deletion operation");
            StringBuilder stringg = new StringBuilder(@"DELETE FRom ");
            stringg.Append(Console.ReadLine());
            stringg.Append("where sector_id = ");
            stringg.Append(Console.ReadLine());
            Console.WriteLine(stringg);

            //string stringg = @"Delete from sectors where sector_id = 11";
            using (SqlConnection con = new SqlConnection(sb.ToString()))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(stringg.ToString(), con))
                {
                    cmd.ExecuteNonQuery();
                }

            }
        }

        private static void InsertData(StringBuilder sb)
        {
            Console.WriteLine("Please enter the data to be inserted");
            string insertdatstring = @"Insert into sectors values('" + Console.ReadLine() + "')";
            Console.WriteLine(insertdatstring);
            using (SqlConnection con = new SqlConnection(sb.ToString()))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(insertdatstring, con))
                {
                    cmd.ExecuteNonQuery();
                }

            }
        }

        static void Display(StringBuilder sb)
        {
            string selectALLString = @"Select * from sectors";
            using (SqlConnection con = new SqlConnection(sb.ToString()))
            {
                con.Open();

                /*Error Execute reader : connection property is not intialised*/
                // using (SqlCommand cmd = new SqlCommand(selectALLString))
                using (SqlCommand cmd = new SqlCommand(selectALLString, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"the sectors id:{rdr[0]}| sectorsName:{rdr[1]}");
                    }
                    Console.ReadLine();
                }
            }
        }
    }
}
