﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{

    delegate int MyDel(int i, int j);
    class ProgramCal
    {
        static void Main(string[] args)
        {

            //1.Display Menu
            DisplayMenu();
            //2.Get user's choice of operation
            int choice = GetIntput("Choice");
            //3.Get operands
            int num1 = GetIntput("Number 1");
            int num2 = GetIntput("Number 2");
            //4.Perform operation
            int i = 6;
            int j = 9;
            int result = 0;
            switch (choice)
            {
                case 1:
                    sum();
                    break;
                case 2:
                    sub();
                    break;
                
            }
            //5.Display result
            Console.WriteLine(result);
        }
        private static int GetIntput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            return val;
        }

      
        int i = 6;
        int j = 9;
        MyDel del = sum;
        del += sub;

           int result = sum(i, j);
        int res = sub(i, j);
        Console.WriteLine($"the sum is {result} the diff is {res}");
            Console.ReadKey();
        }
    private static int sum(int i, int j)
    {
        return i + j;
    }
    private static int sub(int i, int j)
    {
        return i - j;
    }
    private static void DisplayMenu()
        {
            Console.WriteLine("1.ADD");
            Console.WriteLine("2.SUB");
            Console.WriteLine("3.MUL");
            Console.WriteLine("4.DIV");
        }
    }
}

