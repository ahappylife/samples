﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{

    delegate int MyDel(int num1, int num2);
    class ProgramCal
    {
        static void Main(string[] args)
        {

            //Display Menu
            DisplayMenu();

            //Delegate
            MyDel del = sum;
            del += sub;
            del += mul;

            //Get user's choice of operation
            int choice = GetIntput("Choice");

            //Get operands
            int num1 = GetIntput("Number 1");
            int num2 = GetIntput("Number 2");

            //Perform operation
            int result = 0;
            switch (choice)
            {
                case 1:
                    result = del(num1, num2);
                    break;
                case 2:
                    result = del(num1, num2);
                    break;
               case 3:
                    result = del(num1, num2);
                    break;
               
            }

            //Display result
            Console.WriteLine(result);
            Console.ReadKey();
       }
        private static int GetIntput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            return val;
        }


        //Delegate code

        public static int sum(int num1, int num2)
        {
            int result;
            result= num1 + num2;
            return result; 
        }
        public static int sub(int num1, int num2)
        {

            int result;
            result = num1 - num2;
            return result;
        }
        public static int mul(int num1, int num2)
        {
            int result;
            result = num1 * num2;
            return result;
        }
        private static void DisplayMenu()
        {
            Console.WriteLine("1.ADD");
            Console.WriteLine("2.SUB");
            Console.WriteLine("3.MUL");
}
    }
}
