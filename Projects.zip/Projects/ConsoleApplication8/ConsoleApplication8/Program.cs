﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    delegate int MyDel(int i, int j);
    class Program
    {
        static void Main(string[] args)
        {

            
            int i = 6;
            int j = 9;
            MyDel del = sum;
            del += sub;

           int result= sum(i,j);
           int res= sub(i, j);
            Console.WriteLine($"the sum is {result} the diff is {res}");
            Console.ReadKey();
        }
        private static int sum(int i,int j)
        {
            return i + j;
        }
        private static int  sub(int i, int j)
        {
            return i - j;
        }
    }
}
