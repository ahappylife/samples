﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{


    class Program
    {
        static void Main(string[] args)
        {

            //1.Display Menu
            DisplayMenu();
            //2.Get user's choice of operation
            int choice = GetIntput("Choice");
            //3.Get operands
            int num1 = GetIntput("Number 1");
            int num2 = GetIntput("Number 2");
            //4.Perform operation

            int result = 0;
            switch (choice)
            {
                case 1:
                    result = num1 + num2;
                    break;
                case 2:
                    result = num1 - num2;
                    break;
                case 3:
                    result = num1 * num2;
                    break;
                case 4:
                    result = num1 % num2;
                    break;

            }
            //5.Display result
            Console.WriteLine(result);
        }
        private static int GetIntput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            return val;
        }

        private static void DisplayMenu()
        {
            Console.WriteLine("1.ADD");
            Console.WriteLine("2.SUB");
            Console.WriteLine("3.MUL");
            Console.WriteLine("4.DIV");
        }
    }
}

