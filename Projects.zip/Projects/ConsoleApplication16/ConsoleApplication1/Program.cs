﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
          
            int area = 0;
            int peri=0;
            rect(5, 4, out area, out peri);
            Console.WriteLine(area);
            Console.WriteLine(peri);
            Console.ReadKey();
        }

        private static void rect(int a, int b, out int area, out int peri)
        {
            area = a * b;
            peri = 2 * (a + b);
        }

        
    }
}
