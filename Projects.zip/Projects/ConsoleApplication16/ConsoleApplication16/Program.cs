﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication16
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 4;
            NewMethod(ref a);
            Console.WriteLine(a);
            Console.ReadKey();
        }

       
     private static void NewMethod(ref int a)
        {
            a = a + a;
          //  Console.WriteLine($"sum {0}", a);
        }
    }
}
