﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            
            DisplayMenu();
           
            int choice = GetIntput("Choice");

            
        }
        private static int GetIntput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            return val;
        }

        private static void DisplayMenu()
        {
            Console.WriteLine("1.SalariedEmployee");
            Console.WriteLine("2.ContractEmployee");
            
        }

    }
}
