﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication20
{
    class Program
    { static volatile bool isThreadStop = false;
        {
        static void Main(string[] args)
        {
            Console.WriteLine("start");
            Thread th = new Thread(new threadStart(LongMethod));
            th.Start();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"inside{i}");
                th.Start(500);
                if (i == 3)
                {
                    isThreadStop = true;
                }
            }
            Console.WriteLine("end");
            Console.ReadKey();
        }


        private static void LongMethod()
        {
            try
            {
                Console.WriteLine("start");
                for(int i=0;i<20;i++)
                {
                    if (!isThreadStop)
                    {
                        Console.WriteLine($"debug");
                        Console.WriteLine($"inside long method");
                        Thread.Sleep(2000);
                    }
                    else
                        break;
                }
            }
       catch(ThreadAbortException ex)
            {
                Console.WriteLine($"Exception{ex.Message}");
            }
            Console.WriteLine("long Method end");
        }
    }
}
