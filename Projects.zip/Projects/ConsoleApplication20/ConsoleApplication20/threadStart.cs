﻿namespace ConsoleApplication20
{
    internal class threadStart
    {
        private long v;

        public threadStart(long v)
        {
            this.v = v;
        }
    }
}