﻿using System;
namespace ConsoleApplication3
{
    class Samp
    {
        public string p1, p2;
        public Samp()     // Default Constructor
        {
            p1 = "Welcome";
            p2 = "Aspdotnet-Suresh";
        }
    }
    class Prog
    {
        static void Main(string[] args)
        {
            Samp obj = new Samp();   // Once object of class created automatically constructor will be called
            Console.WriteLine("1{0} \n 2{1}",obj.p1,obj.p2);
            
            Console.ReadKey();
        }
    }
}