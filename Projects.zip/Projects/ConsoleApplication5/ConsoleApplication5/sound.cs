﻿using System;
namespace ConsoleApplication3
{
    class Sample
    {
        public string param1, param2;
        public Sample()     // Default Constructor
        {
            param1 = "Welcome";
            param2 = "Aspdotnet-Suresh";
        }
    }
    class Program
    {
        public static void main(string[] args)
        {
            Sample obj = new Sample();   // Once object of class created automatically constructor will be called
            Console.WriteLine(obj.param1);
            Console.WriteLine(obj.param2);
            Console.ReadLine();
        }
    }
}