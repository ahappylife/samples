﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace NestedStructures
{
    struct student
    {
        public string studentname;
        public string rollno;
        public static string grade;
        public string Rollno
        {
            set
            {
                rollno = "s00018_ClassV";
            }
            get
            {
                return rollno;
            }
        }
        public class nestedstructure
        {
            public string schoolname;
            public string calssname;
            public string schoolproperty
            {
                set
                {
                    schoolname = value;
                }
                get
                {
                    return schoolname;
                }
            }

            public school()
            {
                schoolname = "St.Sofia school Meerut, Cantt ";
                classname = "ClassVth";
            }
            public void insert_details(string str1, string str2)
            {
                schoolname = str1

                classname = str2;
            }
            public void show_details()
            {
                Console.WriteLine("school name is {0}", schoolname);
                Console.WriteLine("Class is{0}", classname);
            }
            public struct teachers
            {
                public string tcode;
                public string tname;
                public void getValues(string st, string str)
                {
                    grade = "PGT";
                    tcode = "st";
                    tname = "str";
                }
                public void show()
                {
                    Console.WriteLine("Teacher code is {0}", tcode);
                    Console.WriteLine("Teacher name  {0}", tname);
                }
                public void addstudents()
                {
                    studentname = "Kuldeep Hooda";
                    rollno = "000055_calss4";
                }
                public void addstudents(string str3, string str4)
                {
                    studentname = "str3";
                    rollno = "str4";
                }
                public void show()
                {
                    Console.WriteLine("Student name is {0}", studentname);
                    Console.WriteLine("rollnumber is {0}", rollno);
                }

            }
            class program
            {
                static void Main(string[] args)
                {
                    student st = newstudent();
                    st.rollno = "s0007_calss3";
                    Console.WriteLine("rollno after overriding the property{0}", st.rollno);
                    student.teachers te = newstudent.teachers();
                    te.tcode = "T00014";
                    te.tname = "Rajeev Punia";
                    te.getvales("T000015", "Sanjeev Kumar");
                    te.show();
                    student.teachers intf1 = new student.teachers();
                    intf1.getvalues("T00014", "Amit Mohan");
                    intf1.show();
                    student.school ee = new student.school();
                    ee.schoolproperty = "St Sofia School Meerut,Cantt";

                    ee.show_details();
                }
            }
        }
    }
}