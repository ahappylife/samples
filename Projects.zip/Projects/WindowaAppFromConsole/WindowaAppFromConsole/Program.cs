﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;


namespace WindowaAppFromConsole
{
    class Program
    {   [STAThread]
        static void Main(string[] args)
        {
            Window window = new Window();
            window.Height = 200;
            window.Width = 300;
            window.Title = "abcd";


            Button btn = new Button();
            btn.Height = 23;
            btn.Width = 75;
            btn.Content = "click";
            btn.Click += Btn_Click;
         // btn.Click += (s, e) => { MessageBox.Show("Hello World"); };
            window.Content = btn;

            Color color = new Color();
            color.R = 0;
            color.G = 0;

            color.B = 255;
            color.A = 255;

            SolidColorBrush scb = new SolidColorBrush();
            scb.Color = color;
            window.Background = scb;


            Application app = new Application();
            app.Run(window);

        }
            private static void Btn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello");
        
        }
    }
}
