﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication23
{
    class Program
     {
            public static void Main(string[] args)
            {
                


                Console.WriteLine("Enter your age:\n");
                int age = Convert.ToInt32(Console.ReadLine());
                if (age < 18)
                {
                    goto ineligible;
                }
                else
                {
                    Console.WriteLine("You are eligible to vote!");
                }

            ineligible:
            Console.WriteLine("You are not eligible to vote!");
          }

       }
}
    

