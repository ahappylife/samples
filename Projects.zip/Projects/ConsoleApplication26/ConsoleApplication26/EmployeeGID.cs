﻿namespace ConsoleApplication26
{
    public class EmployeeGID
    {
    }
}