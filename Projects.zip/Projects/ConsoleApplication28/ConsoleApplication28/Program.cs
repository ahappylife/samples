﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIDMapping
{
    class GIDMapping
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            List<int> list1 = new List<int>();
            Console.WriteLine("Enter the number of Associate:");
            int n = int.Parse(Console.ReadLine());
            Random r = new Random();
            Console.WriteLine("Enter the GID number:");
            for (int i = 1; i <= n; i++)
            {
                list.Add(int.Parse(Console.ReadLine()));
                int number;
                do number = r.Next(1, n);
                while (list1.Contains(number));
                if (number != 0)
                    list1.Add(number);
            }
            string stringarray = string.Join(",", list.ToArray());
            string stringarray1 = string.Join(",", list1.ToArray());
            Console.WriteLine(stringarray);
            Console.WriteLine(stringarray1);
            Console.ReadKey();
        }

    }

}