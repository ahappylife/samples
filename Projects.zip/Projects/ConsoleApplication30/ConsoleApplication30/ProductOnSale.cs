﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    class ProductOnSale : Product, IProduct
    {
        public int QuantityOnSale { get; set; }
        public List<int> BatchID = new List<int>();
        public ProductOnSale()
        {
            Console.WriteLine(" **PRODUCT CLASS IMPLEMENTATION**");
            Console.WriteLine("FOR DESCRIPTION ENTER CHOICE OF ANY OF THE FOLLOWING");
            Console.WriteLine("1.For Adding the Product");
            Console.WriteLine("2.For Removing the Product");
            Console.WriteLine("3.For Modifying the Product");
            Console.WriteLine("4.To know Discount of the product purchased");
            Console.WriteLine("5.To know quantity of product in Sale");
            
            ProductCode = Convert.ToInt32(Console.ReadLine());
        }
        public void AddProduct(int pcode)
        {
            int b;
          
            Console.WriteLine("Enter ID");
            b = Convert.ToInt32(Console.ReadLine());
            BatchID.Add(b);
            ProductCode = pcode;
            QuantityOnSale += 1;
            
        }
       
        public void RemoveProduct(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                p.CategoryCode = 0;
                p.ProductCode = 0;
                p.ProductName = null;
                ProductCount -= 1;
            }
        }
        public void RemoveProduct(int pcode, string pname)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                p.CategoryCode = 0;
                p.ProductCode = 0;
                p.ProductName = null;
                ProductCount -= 1;
            }
        }
        public double GetQuantityOnSale()
        {
            Console.WriteLine("The Quantity on Sale is:{0}", ProductCount);
            return QuantityOnSale;
        }
        public string GetProductDesc(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                return (p.ProductCode + "\n" + p.ProductName + "\n" + p.CategoryCode).ToString();
            }
            else
                return "No Record Found";
        }
        public int GetCategoryCode(int pcode)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductCode == pcode)
            {
                return p.CategoryCode;
            }
            else
                return 0;
        }
        public int GetProductCode(string pname)
        {
            ProductOnSale p = new ProductOnSale();
            if (p.ProductName.Equals(pname))
            {
                return p.ProductCode;
            }
            else
                return 0;
        }
        public double GetDiscountPercent(int pcode)
        {
            double perc = 1.0;
            return perc;
        }
        public override string ToString()
        {
            return BatchID + "\n" + ProductCode + "\n" + ProductName + "\n" + CategoryCode;
        }

        public List<string> GetALLProducts()
        {
            throw new NotImplementedException();
        }

        public float scountPercent(int pcode)
        {
            throw new NotImplementedException();
        }

        float IProduct.GetQuantityOnSale()
        {
            throw new NotImplementedException();
        }
    }
}
