﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    interface IProduct
    {
        int GetProductCode(string PName);
        List<string> GetALLProducts();
        string GetProductDesc(int pcode);
        int GetCategoryCode(int pcode);
        float scountPercent(int pcode);
        float GetQuantityOnSale();

    }
}
