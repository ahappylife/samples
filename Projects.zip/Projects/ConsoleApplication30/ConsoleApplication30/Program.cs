﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> p = new List<Product>();
            Product p1 = new Product();
            ProductOnDiscount p2 = new ProductOnDiscount();
            ProductOnSale p3 = new ProductOnSale();
            List<ProductOnSale> ps = new List<ProductOnSale>();
            List<ProductOnDiscount> pd = new List<ProductOnDiscount>();
          

            int op, ch;

            do
            {
                op = Convert.ToInt32(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        p1.AddProduct(p);


                        break;
                    case 2:
                        Console.WriteLine("Enter Id");
                        p1.RemoveProduct(p1);
                        Console.WriteLine(p1.ToString());

                        break;
                    case 3:
                        
                        Console.WriteLine("Enter Product Code");
                        int a;
                        a = Convert.ToInt32(Console.ReadLine());

                        p1.ModifyProduct(a);
                        Console.WriteLine("The modified details of product is:");
                        Console.WriteLine(p1.ToString());
                        break;

                    case 4:
                        int a1;
                        Console.WriteLine("Enter the productcode  of the product");
                        a1 = Convert.ToInt32(Console.ReadLine());
                        p2.GetDiscountPercent(a1);
                        break;

                    case 5:
                        int a2;
                        Console.WriteLine("Enter the productcode  of the product");
                        a2 = Convert.ToInt32(Console.ReadLine());
                        p3.AddProduct(a2);
                        p3.GetQuantityOnSale();
                        break;
                   

                    case 6:
                        Console.WriteLine("Exit");
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;

                }
                Console.WriteLine("Do you want to continue(y/n)?:");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'Y' || ch == 'y');

            p.Sort();
            Console.WriteLine("Sorted List is:");

        }

    }
}





