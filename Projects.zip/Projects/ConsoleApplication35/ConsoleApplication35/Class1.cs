﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication35
{
    class Class1
    {
        static string conString = ConsoleApplication35.Properties.Settings.Default.conString;
        static void Main(string[] args)
        {

            try
            {
                InsertData();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

      }

        private static void InsertData()
        {

            using (SqlConnection con = new SqlConnection(conString))
            {
                string selectString = @"select * from Employees;";
                con.Open();
                using (SqlCommand cmd = new SqlCommand(selectString, con))
                {
                    DataSet ds = new DataSet();
                    SqlDataAdapter da = new SqlDataAdapter(selectString, con);

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Fill(ds);

                    DataRow dr = ds.Tables[0].NewRow();
                    dr["FirstName"] = "Donald";
                    dr["LastName"] = "Trump";
                    DataTable dt = ds.Tables[0];
                    dt.Rows.Add(dr);

                    da.Update(ds);
                }
            }
        }
    }
}
   
