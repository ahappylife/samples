﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication22
{
  abstract class Accounts
    {
        protected readonly int Account_Number;
        protected string User_Name;
        protected int balance;

        public abstract void OpenAccount();
        public abstract void CloseAccount();
        public abstract void EditAccount();
        public abstract void Deposit();
        public abstract void Withdrawal();
        public abstract void Check_Balance();

      public Accounts()
        {
            Console.WriteLine("Enter the name");
            string user_name = Console.ReadLine();
        }

        class BankAccount
        {
            public static void Main(String[] args)
            {
                SavingsAccount sa = new SavingsAccount();
                CurrentAccount ca = new CurrentAccount();
            }
        }

    }
}
