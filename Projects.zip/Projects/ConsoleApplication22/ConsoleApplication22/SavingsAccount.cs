﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication22
{

    class SavingsAccount : Accounts,Iroi,Itransaction
    {
        private string user_name;
        private int w;
        private int MaxAmountPerDay = 30000;


        public override void OpenAccount()
        {

            // Account number generation 
           
            Console.WriteLine("The Account Number is");
            Random r = new Random();
            string w = "";

            List<string> li = new List<string>();
            li.Add(w);
            foreach (int accnumber in w)
            {
                int i;
                for (i = 1; i < 13; i++)
                {
                    w += r.Next(1, 9).ToString();
                }
                if (w.Length == 12)
                {
                    Console.WriteLine(w);
                }

                Console.ReadLine();
                Console.WriteLine("Unique Account Number Created");

            }


            // Checking minimum account balance

            int min_acc_balance = 1000;
            int amount_to_deposit;
            amount_to_deposit=int.Parse(Console.ReadLine());

            
            if(min_acc_balance<1000)
            {
                Console.WriteLine("New Account cannot be created");
                Console.WriteLine("Minimum Balance should be 1000 for creating new account");

            }

            else
            {
                Console.WriteLine($" Your new Account {w} is created" );
            }
          

        }



        // deposit amount

        public override void Deposit()
        {

            Console.WriteLine("Enter the account number");
            int holderaccnumber = Convert.ToInt32(Console.ReadLine());
           
            Console.WriteLine("Enter the amount");
            double balance = Convert.ToInt32(Console.ReadLine());

            if (holderaccnumber == w)
            {
                Console.WriteLine("Enter the amount to deposit");
                double amount;
                double.TryParse(Console.ReadLine(), out amount);
                balance = balance + amount;
            }

            else
            {
                Console.WriteLine("Invalid account number");

            }
            
            Console.ReadLine();

        }



        //withdraw amount


            public override void Withdrawal()
        {
            Console.WriteLine("Please enter the account number");
            int holderaccnumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the amount");
            double wbalance = Convert.ToInt32(Console.ReadLine());


            if (wbalance>30000)
            {
                throw new Exception("You can not withdraw amount from your Savings Account as Minimum Balance limit is reached");
            }


            else {
                if (holderaccnumber == w)
                {
                    Console.WriteLine("Enter the amount to withdraw");
                    double amount;
                    double.TryParse(Console.ReadLine(), out amount);
                    wbalance = balance - amount;
                }

                else
                {
                    Console.WriteLine("Invalid account number");

                }
            }
        }

        //check balance


        public override void Check_Balance()
        {
            Console.WriteLine($"Available balance is {balance}"); 
        }



        // editing user name

        public override void EditAccount()
        {
            string new_user_name = Console.ReadLine();
            Console.WriteLine($"New user name is {new_user_name}");
            user_name = new_user_name;
        }



        // close account

        public override void CloseAccount()
        {
            if (balance == 0)
            {
                Console.WriteLine("");
            }  
        }

        public void GetAccountDetails()
        {
            Console.WriteLine($"The Account Holder Name is {user_name}");
            Console.WriteLine($"The Account Number is {w}");
            Console.WriteLine($"The Available Balance is {balance}");
        }

        public void RateOfInterest()
        {
            throw new NotImplementedException();
        }

        public void TransferAmount()
        {
            throw new NotImplementedException();
        }
    }


}

