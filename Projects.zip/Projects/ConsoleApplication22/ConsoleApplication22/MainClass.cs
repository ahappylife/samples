﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication22
{
    class MainClass
    {
        Accounts sa = new SavingsAccount();
        Accounts ca = new CurrentAccount();

    }
}

