﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
   
static void Main(string[] args)
    {
        int counter = 0;
        int product = 1;
        Console.WriteLine("Enter a whole number from 1 to 5:");
        int number;
        Int32.TryParse(input, out number);

        while (counter > 1)
        {

            product *= counter--;
        }
        cout << "The factorial is: " << product;
        cout << ""--counter;


        return 0;
    }
    }
