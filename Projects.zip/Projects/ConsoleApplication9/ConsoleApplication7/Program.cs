﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class ValueOfMoney
    {
        static void Main(string[] args)
        {
            double amount, principal, rate, CIfreq, year, interest;
            Console.WriteLine(" Enter the amount");
            double.TryParse(Console.ReadLine(), out amount);
            Console.WriteLine(" Enter the principal");
            double.TryParse(Console.ReadLine(), out principal);
            Console.WriteLine(" Enter the rate");
            double.TryParse(Console.ReadLine(), out rate);
            Console.WriteLine(" Enter the CIfreq");
            double.TryParse(Console.ReadLine(), out CIfreq);
            Console.WriteLine(" Enter the year");
            double.TryParse(Console.ReadLine(), out year);
            double temp = (1 + rate / year);
            amount = principal * Math.Pow(temp, (CIfreq * year));
            interest = amount - principal;
            Console.WriteLine(" Principal Amount {0}",principal);
            Console.WriteLine(" Interest {0}",interest);
            Console.WriteLine(" Period in Years {0}", year);
            Console.WriteLine(" Final Value {0}", amount);
            Console.ReadKey();
        }

    }
}
