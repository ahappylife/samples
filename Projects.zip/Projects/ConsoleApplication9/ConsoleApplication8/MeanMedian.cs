﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {

            int n=3;
            float mean, median, std;
            Console.WriteLine("Enter");
                int[] data = new int[n];

                int i = 0;
                for (i = 0; i < n; i++)
                {
                    Console.Write("{0}:", i);
                    data[i] = int.Parse(Console.ReadLine());
                }

                sort(data, n);

                int sum = 0;
                int j = 0;
                while (j < n)
                {
                    sum = sum + data[j];
                    j++;
                }

                mean = (float)sum / n;

                if (n % 2 != 0) median = data[n / 2];
                else median = (data[(n / 2) - 1] + data[n / 2]) / (float)2;


                int[,] mode = new int[n, 2];

                for (i = 0; i < 2; i++)
                    for (j = 0; j < n; j++) mode[j, i] = 0;
                mode[0, 0] = 1;

                for (i = 0; i < n; i++)
                    for (j = 0; j < n - 1; j++)
                        if (data[i] == data[j + 1]) { ++mode[i, 0]; mode[i, 1] = data[i]; }

                int max;
                int k = 0;
                max = mode[0, 0];
                for (j = 0; j < n; j++)
                    if (max < mode[j, 0]) { max = mode[j, 0]; k = j; }

                float temp = 0.0f;

                for (j = 0; j < n; j++)
                {
                    temp = temp + (float)Math.Pow(data[j] - mean, 2);
                }

                std = (float)Math.Sqrt(temp / (n - 1));

                
                Console.WriteLine($"Mean:{0}", mean);
                Console.WriteLine($"Median:{0}", median);
                Console.WriteLine($"Mode:{0}", mode[k, 1]);
                Console.WriteLine($"SD:{0}", std);


            
            Console.ReadLine();
        }
        static void sort(int[] data, int n)
        {
            int i, j;
            for (i = 0; i < n; i++)
                for (j = n - 1; j > i; j--)
                {
                    if (data[j] < data[j - 1])
                    {
                        int temp = data[j];
                        data[j] = data[j - 1];
                        data[j - 1] = temp;
                    }
                }
        }​

        }
    }
