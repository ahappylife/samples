﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class MeanMedian
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[] {10,20,35,40,50};

            //mean

            float total = 0;
            float mean = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                total = total + numbers[i];
            }
            mean = total / numbers.Length;
            Console.WriteLine("The Mean value is {0}",mean);
            

            //median

           
            float midvalue = 0;
            if (numbers.Length % 2 == 0)
            {
                int var = ((numbers.Length) / 2) - 1;
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (var == 1 || (var + 1) == i)
                    {
                        midvalue = midvalue + numbers[i];
                    }
                }
                midvalue = midvalue / 2;
                Console.WriteLine("The median value is{0}", midvalue);
               
            }

            else
            {
                int var = (numbers.Length) / 2;
                for(int i=0;i<numbers.Length;i++)
                {
                    if(var==i)
                    {
                        midvalue = numbers[i];
                        Console.WriteLine("The median value is{0}",midvalue);
                       
                    }
                }
            }
            Console.ReadKey();
        }
    }
 }

