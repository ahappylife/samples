﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class FactorialTen
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 1;
            int c=a+b;
            int count = 0;
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine(a);
            Console.WriteLine(b);
            if (number<0)
            {
                Console.WriteLine("The number is negative");
            }

            else
            {
                while (count < number)
                a = b;
                b = c;
                count++;
                Console.WriteLine("The factorial of first 10 number is");
                Console.WriteLine(c);
                Console.ReadKey();
            }
        }
    }
}
