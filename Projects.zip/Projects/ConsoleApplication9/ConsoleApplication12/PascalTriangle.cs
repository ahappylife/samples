﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication12
{

    class PascalTriangle
    {
        static void Main(string[] args)
        {

            System.Console.WriteLine("Pascal Triangle ");
            

            int n = 10;

            for (int i = 0; i < n; i++)
            {
                int c = 1;
                for (int q = 0; q < n - i; q++)
                {
                    Console.Write("   ");
                }

                for (int j = 0; j <= i; j++)
                {
                    Console.Write(c);
                    Console.Write("   ");
                    c = c * (i - j) / (j + 1);
                }
                
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
