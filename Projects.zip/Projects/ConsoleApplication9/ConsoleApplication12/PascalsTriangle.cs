﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication12
{

    class PascalTriangle
    {
        static void Main(string[] args)
        {

            System.Console.WriteLine("Pascal Triangle ");
            System.Console.Write("Enter the number of rows: ");
            int n = int.Parse(Console.ReadLine());

            for (int y = 0; y < n; y++)
            {
                int c = 1;
                for (int q = 0; q < n - y; q++)
                {
                    System.Console.Write("   ");
                }

                for (int x = 0; x <= y; x++)
                {
                    System.Console.Write("   {0:D} ", c);
                    c = c * (y - x) / (x + 1);
                }
                System.Console.WriteLine();
                System.Console.WriteLine();
            }
            System.Console.WriteLine();
        }
    }
}