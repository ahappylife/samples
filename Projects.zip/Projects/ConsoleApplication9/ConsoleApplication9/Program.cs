﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    class ReversePgm
    {
        static void Main(string[] args)
        {
            int reverse = 0;
            int number = GetInput("Number");

            while (number!=0)
            {
                reverse = reverse * 10;
                reverse = reverse + number % 10;
                number = number / 10;
            }

            Console.WriteLine("The Factorial of a number is",reverse);
        }

        //GetInput

            private static int GetInput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;

                }
                else
                {
                    Console.WriteLine("Error Message");
                }
            }
            return val;
        }


    }
}
