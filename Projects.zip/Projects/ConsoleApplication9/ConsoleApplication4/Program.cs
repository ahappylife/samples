﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication16
{

    class Employee
    {
       
        int _id;
        string nm;
        double sal;       


        static void Main(string[] args)
        {

            Console.Write("Enter number of Employees; ");
            int i = 0;
            int s = int.Parse(Console.ReadLine());

            while (i < s)
            {

                Console.WriteLine("Enter id: ");
                int _id = int.Parse(Console.ReadLine());
                               
                Console.WriteLine("Enter Name: ");
                string nm = Console.ReadLine();
                
                Console.WriteLine("Enter Salary: ");
                double sal = int.Parse(Console.ReadLine());


                i++;
                
            }
        }

        }
    }
    
        
    