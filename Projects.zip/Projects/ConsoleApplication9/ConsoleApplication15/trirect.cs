﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication15
{


    interface rectangle
    {
        int rect(int a, int b);
    }

    interface triangle
    {
        int tri(int x, int y);
    }



    class shape : rectangle, triangle
    {
        public int rectarea;
        public int rect(int a, int b)
        {
            return rectarea = a * b;
        }

        public int triarea;
        public int tri(int x, int y)
        {
            return triarea = (x * y) / 2;
        }




        class TriRect
        {
            static void Main(string[] args)
            {
                shape s = new shape();
                s.rect(4, 6);
                s.tri(4, 6);
                Console.WriteLine($" Area of Rectangle ", s.rectarea);
                Console.WriteLine($" Area of Triangle ", s.triarea);
                Console.ReadKey();
            }
        }
    }
}

