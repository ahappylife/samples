﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class palindrome
    {
        static void Main(string[] args)
        {
            string initial = "";

            Console.WriteLine("Enter a String to check for Palindrome");

            string inputstring = Console.ReadLine();

            int iLength = inputstring.Length;
                        
                for (int j = iLength - 1; j >= 0; j--)
                {
                    initial = initial + inputstring[j];
                }

                if (initial == inputstring)
                {
                    Console.WriteLine($"The string is Palindrome {0}",inputstring);
                }
                else
                {
                Console.WriteLine($"The string is  not Palindrome {0}", inputstring);
            }


                Console.Read();
            }
        }
    }

