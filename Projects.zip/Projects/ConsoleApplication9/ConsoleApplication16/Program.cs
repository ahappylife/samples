﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication16
{
    class DateProgram
    {
        static void Main(string[] args)
        {
            string a = Console.ReadLine();
            string b = Console.ReadLine();

            DateTime dt;
            DateTime dt1;

            int total = 0, month = 0, year = 0;
            bool res = DateTime.TryParseExact(a, "dd/MM/yyy", null, System.Globalization.DateTimeStyles.None, out dt);
            bool res1 = DateTime.TryParseExact(a, "dd/MM/yyy", null, System.Globalization.DateTimeStyles.None, out dt1);

            if(res==true&&res1==true)
            {
                int x = dt.Month;
                int y = dt1.Month;
                int k = dt.Year;
                int l = dt1.Year;
                if(k<l)
                {
                    if(y<x)
                    {
                        month = y - x;
                        year = l - k;
                        if(month<0)
                        {
                            year = year - 1;
                            month = month + 12;
                        }
                    }
                    else if(x<y)
                    {
                        month = x - y;
                        year = k - l;
                        if(month<0)
                        {
                            year = year - 1;
                            month = month + 12;
                        }

                    }
                }
                else if(l<k)
                {
                    if(y<x)
                    {
                        month = y - x;
                        year = l - k;
                        if(month<0)
                        {
                            year = year - 1;
                            month = month + 12;
                        }
                    }
                    else if(x<y)
                    {
                        month = x-y;
                        year = k-l;
                        if (month < 0)
                        {
                            year = year - 1;
                            month = month + 12;
                        }
                    }
                }
                else if(k==l)
                {
                    if(y<x)
                    {
                        month = x - y;
                        year = l - k;
                        if (month < 0)
                        {
                            year = year - 1;
                            month = month + 12;
                        }
                    }
                    else if (x<y)
                    {
                        month = y - x;
                        year = k - l;
                        if(month<0)
                        {
                            year = year - 1;
                            month = month + 12;
                        }
                    }
                }
                total = year * 12 + month;
            }
            Console.WriteLine(total);
            Console.ReadLine();
        }
    }
}
