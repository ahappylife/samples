﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class FibonacciTen
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 1;
            int c;
            int count = 0;
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
           
            if (number < 0)
            {
                Console.WriteLine("The number is negative");
            }
            else
            {
                while (count < number)
                {
                    Console.WriteLine("The fibonacci series of first 10 number is");
                    c = a + b;
                    Console.WriteLine(c);
                    a = b;
                    b = c;
                    count++;
                  
                }
            }

            Console.ReadKey();
        }
    }
}
