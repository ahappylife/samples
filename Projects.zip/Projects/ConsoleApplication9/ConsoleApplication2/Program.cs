﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] matrix = new int[][]
{
new int[] {0,1,2,},
new int[] {3,4,5,},
new int[] {6,7,8,9}
};



            for (int i = 0; i < matrix.Length; i++)
            {
                matrix[i] = new int[4]; // Create inner array
                for (int j = 0; j < matrix[i].Length; j++)
                    matrix[i][j] = i * 3 + j;
            }
            Console.WriteLine($"the matrix is {matrix[2][3]}");
            Console.ReadKey();
        }
    }
}
