﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    enum MenuOptions
    {
        add =1,sub=2
    };
    
    class Program
    {
        static void Main(string[] args)
        {

            //1.Display Menu
            DisplayMenu();
            //2.Get user's choice of operation
            int choice = GetInt("Choice");
            //3.Get operands
            int num1 = GetInt("Number 1");
            int num2 = GetInt("Number 2");
            //4.Perform operation
            int result = 0;
        
        }
        private static int GetInt(string message)
        {
            int val;
            while(true)
            {
                Console.WriteLine(message);
                if(int.TryParse(Console.ReadLine(),out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error");
                }
            }
            return val;
        }

        private static void DisplayMenu()
        {
            Console.WriteLine("1.ADD");
            Console.WriteLine("2.SUB");
            Console.WriteLine("3.MUL");
            Console.WriteLine("4.DIV");
        }
    }
}
