﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO1
{
    class Program
    {
        static string conString = @"Server = INCHCMPC08679; Database = NorthWind;
                Trusted_Connection = yes;";


        static void Main(string[] args)
        {
            string Confirm = " ";
            try
            {
                do
                {
                    Console.WriteLine("enter the choice");
                    displaymenu();
                    int ch = Convert.ToInt32(Console.ReadLine());

                    switch (ch)
                    {
                        case 1:
                            DisplayData();
                            break;
                        case 2:
                            InsertData();
                            break;
                        case 3:
                            UpdateData();
                            break;

                        case 4:
                            DeleteData();
                            break;

                        case 5:
                            DisplayCount();
                            break;

                    }
                    Console.WriteLine("Enter Y to Continue");
                    Confirm = Console.ReadLine().ToUpper();
                } while (Confirm == "Y");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();

        }

        private static void displaymenu()
        {

            Console.WriteLine("1.Display content of Table");
            Console.WriteLine("2.Insert Data to Table");
            Console.WriteLine("3.Update Data in Table");
            Console.WriteLine("4.Delete the Records");
            Console.WriteLine("5.Count the Records");
        }

        private static void DeleteData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string updateString = @"DELETE FROM Employees WHERE EmployeeId=2 ";
                using (SqlCommand cmd = new SqlCommand(updateString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }


        private static void UpdateData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string updateString = @"UPDATE Employees SET FirstName=@FirstName, LastName=@LastName  WHERE EmployeeId = @Id";
                using (SqlCommand cmd = new SqlCommand(updateString, con))
                {

                    Console.WriteLine("Enter ID");
                    cmd.Parameters.AddWithValue("@Id", Console.ReadLine());


                    Console.WriteLine("enter FirstName");
                    cmd.Parameters.AddWithValue("@FirstName", Console.ReadLine());


                    Console.WriteLine("Enter LastName");
                    cmd.Parameters.AddWithValue("@LastName", Console.ReadLine());

                    int rows = cmd.ExecuteNonQuery();

                }
            }
        }


        private static void InsertData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string insertString = @"INSERT INTO Employees (FirstName, LastName) VALUES (@FirstName,@LastName) ";

                using (SqlCommand cmd = new SqlCommand(insertString, con))

                {
                    Console.WriteLine("enter FirstName");
                    cmd.Parameters.AddWithValue("@FirstName", Console.ReadLine());
                    Console.WriteLine("Enter LastName");
                    cmd.Parameters.AddWithValue("@LastName", Console.ReadLine());


                    int rows = cmd.ExecuteNonQuery();

                }

            }

        }


        private static void DisplayData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"SELECT * FROM EMPLOYEES";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"id:{rdr["EmployeeId"]} | FirstName: {rdr["FirstName"]}  | LastName: {rdr["LastName"]} | City:{rdr["city"]}");
                    }
                }

            }
        }

        private static void DisplayCount()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"SELECT COUNT(*) FROM EMPLOYEES";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    int count = (int)cmd.ExecuteScalar();
                    Console.WriteLine($"Total no. of records = {count}");
                }
            }
        }

    }
}