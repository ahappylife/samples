﻿using ConsoleApplication17;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication17
{
    static class Program
    {
        public static void sayhello(this employee1 e, manager1 m)

        {
            Console.WriteLine($"{e.id}{e.name}");
            Console.WriteLine($"{m.id}{m.name}");

        }
        public static void sayhello(this List<employee1>list)

        {
            
            Console.WriteLine(list[0].id);

        }
    }

        class employee1
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        class manager1
        {
            public int id { get; set; }
            public string name { get; set; }
        }


    class program1
    { 

        static void Main(string[] args)
        {
            employee1 e = new employee1 { id = 2, name = "abc" };
            manager1 m = new manager1 { id = 3, name = "abc" };
            employee1 e1 = new employee1 { id = 3, name = "abc" };
            e.sayhello(m);

           
            List<employee1> list = new List<employee1>();
            list.Add(e);
            list.Add(e1);
            list.sayhello();
        }

    }

}


