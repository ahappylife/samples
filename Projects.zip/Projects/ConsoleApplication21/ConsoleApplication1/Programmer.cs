﻿namespace ConsoleApplication1
{
    internal class Programmer
    {
        internal object name;
        internal object salary;
    }
}