﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        public class stu
        {
            public int salary = 90;
        }
        public class Programmer : stu
        {
            public string name = "abi";
        }
        class inherit
        {
            static void Main(string[] args)
            {
                Programmer p1 = new Programmer();
                Console.WriteLine($"The salary is{p1.salary}");
                Console.WriteLine($"name is{p1.name}");
                Console.ReadKey();

            }
        }
    }
}
