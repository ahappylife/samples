﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication21
{
    public class employee11
    {
        public int id;
        public string name;
        public int num;

        public employee11(int id, string name, int num)
        {
            this.id = id;
            this.name = name;
            this.num = num;
        }
        public void display()
        {
            Console.WriteLine($"The details are {id} {name}{num}");
           
        }
       
 }
class struc
{
      public  static void Main(string[] args)
        {
            employee11 e1 = new employee11(1, "abi", 4);
            employee11 e2 = new employee11(2, "abc", 6);
            e1.display();
            e2.display();
            Console.ReadKey();
        }
}
}
