﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApplication29
{
    class ProductOnSale: Product,IProduct
    {
        int QuantityOnSale;

        public ProductOnSale(string PCOde, string ProName, int CCOde, int PCOunt) : base(PCOde, ProName, CCOde, PCOunt)
        {
            Console.WriteLine("");
        }

        public int CatCode { get; private set; }
        public int ProName { get; private set; }
        public int ProQuantity { get; private set; }


        public override void AddProduct()
        {
            Console.WriteLine("Enter the ProductCode");
            string ProductCode = (Console.ReadLine());

            // validation
            Regex reg = new Regex(@"^([A-Z]{3}-[0-9]{3})+$");
            if (reg.IsMatch(ProductCode))
            {
                Console.WriteLine("Valid Product Code");
                Console.WriteLine("Product added successfully ");
                Console.ResetColor();
                Console.WriteLine("ProductName:{0}", ProName);
                Console.WriteLine("AccountName:{0}", CatCode);
                Console.WriteLine("AccountBalance:{0}", ProQuantity);

            }
            else
            {
                Console.WriteLine("Not a Valid Product Code");
                Console.WriteLine("Enter a Valid Product Code");
            }
            Console.ReadLine();


        }

        public override void RemoveProduct()
        {
            Console.WriteLine("Enter the Product Code");
            string UProductCode = (Console.ReadLine());
            int count = 0;
            foreach (var item in MainClass.PSale)
            {
                count++;

                //exception
                try
                {
                    if (item.ProductCode == UProductCode)
                    {
                        if (item.ProductCode == "")
                        {
                            MainClass.PSale.Remove(item);
                        }
                        else
                        {
                            throw new ProductRemoval((" Enter valid Product Code"));
                        }
                    }
                    else if (count == MainClass.PSale.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Enter the valid product code");
                        Console.ResetColor();
                    }
                }
                catch (ProductRemoval e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
            }
        }



        public override void ModifyProduct()
        {
            Console.WriteLine("Enter the Product Code");
            string UProductCode = (Console.ReadLine());
            int count = 0;
            foreach (var item in MainClass.Pdiscount)
            {
                count++;
                if (item.ProductCode == UProductCode)
                {
                    Console.WriteLine("ProductCode:{0}", item.ProName);
                    Console.WriteLine("Enter the product to be modified");
                    item.ProName = Console.ReadLine();
                    Console.WriteLine("Your product is modified successfully");
                    Console.WriteLine("ProductName:{0}", item.ProName);

                }

                else if (count == MainClass.Pdiscount.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Product does not exixst");
                    Console.ResetColor();
                }

            }

        }

        public void GetDiscountPercentage()
        {
           
        }
    }
}
