﻿using System;
using System.Runtime.Serialization;

namespace ConsoleApplication29
{
    [Serializable]
    internal class ProductRemoval : Exception
    {
        public ProductRemoval()
        {
        }

        public ProductRemoval(string message) : base(message)
        {
        }

        public ProductRemoval(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ProductRemoval(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}