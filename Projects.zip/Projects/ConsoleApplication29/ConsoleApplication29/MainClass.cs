﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication29
{
    class MainClass
    {
        public static List<ProductOnSale> PSale = new List<ProductOnSale>();
        public static List<ProductOnDiscount> Pdiscount = new List<ProductOnDiscount>();
        static void Main(string[] args)
        {

        }
    }
}
