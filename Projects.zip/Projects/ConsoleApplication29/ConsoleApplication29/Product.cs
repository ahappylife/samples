﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication29
{

    //Constructor
   public abstract class Product
    {
        public string ProductCode;
        public string ProductName;
        public int CategoryCode;
        public static int ProductCount;

        public Product(string PCOde,string ProName,int CCOde,int PCOunt)
        {
            this.ProductCode = PCOde;
            this.ProductName = ProName;
            this.CategoryCode = CCOde;
            Count(PCOunt);
        }

        private void Count(int pCOunt)
        {
           
        }

      
        public abstract void AddProduct();
        public abstract void RemoveProduct();
        public abstract void ModifyProduct();

    }
}
