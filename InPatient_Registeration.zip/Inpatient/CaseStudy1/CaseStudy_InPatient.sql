create database CaseStudy_InPatient
use CaseStudy_InPatient
create table tblPatientRegistration
(
id int identity(100,1),
patientid as('P'+cast(id as varchar)),
firstName varchar(100),
lastName varchar(100),
mobile varchar(10),
address varchar(50),
email varchar(70),
occupation varchar(50),
organisationworking varchar(50),
JoiningDate date,
gender varchar(1),
Reason varchar(100),
userId varchar(10),
Password varchar(20),
)
alter table tblPatientRegistration drop column id
alter table tblPatientregistration drop column caretakername 
alter table tblPatientregistration add Caretakername varchar(50)
select * from tblPatientRegistration
sp_rename 'tblPatientRegistration.userId','userName'
alter proc uspPatientRegister

@firstName varchar(50),
@lastName varchar(50),
@mobile varchar(10),
@address varchar(100),
@email varchar(30),
@occupation varchar(50),
@organisationWorking varchar(50),
@joiningDate Date,
@gender varchar(1),
@reason varchar(50),
@userName varchar(30),
@password varchar(30),
@caretakername varchar(50),
@patientid varchar(10) out
as
begin
exec uspGenerateNewPatientId @patientid out
insert into tblPatientRegistration(firstName,lastName,mobile,address,email,occupation,organisationworking,JoiningDate,gender,Reason,userName,Password,patientid,Caretakername) values(@firstName,@lastName,@mobile,@address,@email,@occupation,@organisationworking,@JoiningDate,@gender,@Reason,@userName,@password,@patientid,@caretakername)
end
--creating a stored procedure to check the patient credentials
alter proc uspPatientLoginCredentails
@UserName varchar(40),
@Password varchar(max),
@res int out
as
begin
if(exists(select * from tblPatientRegistration where @UserName=userName and @Password=Password))
set @res=1
else
set @res=0
end


select * from tblPatientRegistration
truncate table tblPatientRegistration
--creating a procedure to generate the ID for a patient automatically
alter proc uspGenerateNewPatientId
@patientid varchar(10) out
as
begin
declare @newId int
if(exists(select * from tblPatientRegistration))
begin
select @newId=substring(MAX(patientid),2,10)+1 from tblPatientRegistration
set @patientid='p'+CAST(@newid as varchar(8))
end
else 
set @patientid ='p101'
end
select * from tblPatientRegistration
declare @patientId varchar(10) 
exec uspGenerateNewPatientId @patientid out
print @patientid
insert into tblPatientRegistration(firstName,lastName,mobile,address,email,occupation,organisationworking,JoiningDate,gender,Reason,userName,Password,patientid)values('k','k','9999999999','sad','k@gmail.com','sd','asd','1/1/2013','f','dfsd','k','k','p101')
truncate table tblPatientRegistration

--create table for adding a doctor
create table tbladddoctor
(
doctorId varchar(10),
doctorName varchar(50),
qualification varchar(50),
specialization varchar(50),
gender varchar(1),

)
alter table tbladddoctor add MobileNumber varchar(10)
alter table tbladddoctor add userName varchar(30)
alter table tbladddoctor add password varchar(40)
insert into tbladddoctor(doctorId,doctorName,qualification,specialization,gender) values('d101','k','df','df','f')
select * from tbladddoctor;
create proc uspGenerateNewDoctorId
@doctorId varchar(10) out
as
begin
declare @newId int
if(exists(select * from tbladddoctor))
begin
select @newId=substring(MAX(doctorId),2,10)+1 from tbladddoctor
set @doctorId='d'+CAST(@newid as varchar(8))
end
else 
set @doctorId ='d101'
end
declare @doctorId varchar(10) 
exec uspGenerateNewDoctorId @DoctorId out
print @doctorId 

alter proc uspadddoctor
@doctorId varchar(10) out,
@doctorName varchar(50),
@qualification varchar(50),
@specialization varchar(50),
@gender varchar(1),
@MobileNumber varchar(10),
@UserName varchar(30),
@Password varchar(30)
as
begin
exec uspGenerateNewDoctorId @doctorId out
insert into tbladddoctor(doctorId,doctorName,qualification,specialization,gender,MobileNumber,userName,password) values(@doctorId,@doctorName,@qualification,@specialization,@gender,@MobileNumber,@UserName,@Password)
end
select * from tbladddoctor
--create a procedure to check the credentials for doctor
alter proc uspDoctorLoginCredentails
@UserName varchar(40),
@Password varchar(max),
@res int out
as
begin
if(exists(select * from tbladddoctor where @UserName=userName and @Password=password))
set @res=1
else
set @res=0
end

---create procedure for remove doctor
alter proc uspremovedoctor
@did varchar(10),
@status int out
as
begin
if exists(select * from tbladddoctor where doctorId=@did)
delete from tbladddoctor where doctorId=@did 
set @status=1
end
alter proc uspCheckUserWithType  
@uname varchar(50),  
@pwd varchar(20),  
@utype int,
@exists int out  
as  
begin  
if exists(select * from tblcredentials
where @uname=username and @pwd=pwd and @utype=usertype)  
set @exists=1  
else  
set @exists=0  
end
create table tblcredentials
(
username varchar(20),
pwd varchar(20),
usertype int not null 
)
--create table for accomodation
create table Accomodation
(
patientId varchar(10) not null,
RoomType varchar(20) not null,
RoomNum varchar(20) not null,
BedNum varchar(20) not null,
Equipment varchar(20) not null
)
select * from Accomodation
create proc uspAvailabilty
@availabilty varchar(100) output
as
begin
select @availabilty=Roomnum+bednum 
from Accomodation 
end

--creating a procedure to accomodate a patient
create proc uspAllocate
@patientId varchar(10),
@RoomType varchar(20),
@RoomNum varchar(20),
@BedNum varchar(20),
@equipment varchar(20)
as
begin
Insert into Accomodation(patientId,RoomType,RoomNum,BedNum,Equipment) values(@patientId,@RoomType,@RoomNum,@BedNum,@equipment)
end
select * from Accomodation
delete from tblPatientRegistration where patientid='p104'
select * from tbladddoctor
--create a stored procedure to view one doctor
create proc uspViewOneDoctor
@doctorId varchar(10)
as
begin
select * from tbladddoctor where doctorId=@doctorId
end
create proc uspForgotPwd
@uId varchar(10),
@newPwd varchar(50)
as
begin
	if @uid like 'p%'
	begin
	update tblPatientRegistration set password=@newPwd where patientid=@uId
	end
	else if @uid like 'd%'
	begin
	update tbladddoctor set password=@newPwd where doctorId=@uId
	end
end

select * from tblPatientRegistration
select * from tbladddoctor
select * from tblnursingStation
select * from Accomodation
