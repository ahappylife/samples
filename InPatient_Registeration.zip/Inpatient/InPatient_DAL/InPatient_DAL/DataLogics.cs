﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace InPatient_DAL
{
    public class DataLogics
    {
        private static SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=INHYTCPC05302;Initial Catalog=Elite2004;Integrated Security=true");
            return con;
        }
        public int PatientRegistration(string pId, string fname, string lname, string cname, string mobile, string address, string email, string occupation, string orgworking, DateTime joiningdate, string gender, string Reason, string username, string Password)
        {
            int res = 0;
            SqlConnection con = GetConnection();
            SqlCommand cmd = new SqlCommand("uspPatientRegister", con);
            cmd.CommandType = CommandType.StoredProcedure;
           
             cmd.Parameters.AddWithValue("@firstName",fname);
             cmd.Parameters.AddWithValue("@lastName",lname);
             cmd.Parameters.AddWithValue("@caretakername",cname);
             cmd.Parameters.AddWithValue("@mobile",mobile);                                                                      
             cmd.Parameters.AddWithValue("@address",address);
             cmd.Parameters.AddWithValue("@email",email);
             cmd.Parameters.AddWithValue("@occupation",occupation);
             cmd.Parameters.AddWithValue("@organisationWorking",orgworking);
             cmd.Parameters.AddWithValue("@joiningDate",joiningdate);
             cmd.Parameters.AddWithValue("@gender",gender);
             cmd.Parameters.AddWithValue("@reason",Reason);
             cmd.Parameters.AddWithValue("@userName",username);
             cmd.Parameters.AddWithValue("@password",Password);

             SqlParameter resParameter = new SqlParameter("@result", SqlDbType.Int);

             resParameter.Direction = ParameterDirection.Output;

             cmd.Parameters.Add(resParameter);

             cmd.ExecuteNonQuery();
             res = (int)resParameter.Value;

             return res;
          }
        public int Allocate(string patientId,string RoomType,string RoomNum,string BedNum,string equipment)
        {
            SqlConnection con = GetConnection();
            SqlCommand cmd = new SqlCommand("uspAllocate", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@patientId",patientId);
            cmd.Parameters.AddWithValue("@RoomType",RoomType);
            cmd.Parameters.AddWithValue("@RoomNum",RoomNum);
            cmd.Parameters.AddWithValue("@BedNum",BedNum);
            cmd.Parameters.AddWithValue("@equipment",equipment);

            //SqlParameter resParameter = new SqlParameter("@res", SqlDbType.Int);
            //resParameter.Direction = ParameterDirection.Output;
            //cmd.Parameters.Add(resParameter);

            cmd.ExecuteNonQuery();
            return 0;
        }
        public int DeleteDoctor(string docId)
        {
            SqlConnection con = GetConnection();
            SqlCommand cmd = new SqlCommand("uspremovedoctor", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@docId", docId);
            return cmd.ExecuteNonQuery();           

        }
        public DataSet ViewAllDoctors()
        {
            SqlConnection con = GetConnection();
            con.Close();
            SqlDataAdapter da = new SqlDataAdapter("uspviewalldoc", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public int InsertNurseStation(string patientid,int RoomType,int Equipment,int Total)
        {
            int res=0;
            SqlConnection con=GetConnection();
            SqlCommand cmd = new SqlCommand("uspInsertNurseStation", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@patientId",patientid);
            cmd.Parameters.AddWithValue("@RoomType",RoomType);
            cmd.Parameters.AddWithValue("@Equipment",Equipment);
            cmd.Parameters.AddWithValue("@Total", Total);

            SqlParameter resParameter = new SqlParameter("@res", SqlDbType.Int);
            resParameter.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(resParameter);

            cmd.ExecuteNonQuery();
            res = (int)resParameter.Value;
            return res;
       }
        public int AddDoctor(string doctorName,string qualification,string specialization,string gender,string mobile,string username,string password)
        {
            int res=0;
            SqlConnection con=GetConnection();
            SqlCommand cmd=new SqlCommand("uspadddoctor",con);
            cmd.CommandType=CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@doctorName",doctorName);
            cmd.Parameters.AddWithValue("@qualification",qualification);
            cmd.Parameters.AddWithValue("@specialization",specialization);
            cmd.Parameters.AddWithValue("@gender",gender);
            cmd.Parameters.AddWithValue("@MobileNumber",mobile);
            cmd.Parameters.AddWithValue("@UserName",username);
            cmd.Parameters.AddWithValue("@Password", password);

            SqlParameter resParameter = new SqlParameter("@doctorId", SqlDbType.Int);
            resParameter.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(resParameter);

            cmd.ExecuteNonQuery();
            res = (int)resParameter.Value;

            return res;
        }
        

        
    }
}

