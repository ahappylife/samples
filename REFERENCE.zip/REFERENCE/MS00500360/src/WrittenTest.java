import java.util.Random;

public class WrittenTest {
	int marks;
	public int writtenTest(Student student){
		System.out.println(student.name +"is writing the writtentest ");
		
		Random r=new Random();
		marks=r.nextInt(100)+50;
		
		
		if(marks>=50){
			System.out.println("your written marks is "+marks);
			
				
			
		}
		else{
			System.out.println("sorry! you are nor clear the exam ");
		}
		return marks;
		
	}
	
}