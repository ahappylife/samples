import java.util.Random;
import java.util.Scanner;

public class TechnicalRound {
	int technicalSubjectLevel;
	public int technicalInterview(int writtenScore,Student student){
		
		if(writtenScore>50){
		System.out.println(student.name +"please select(number) your areas of interest from the following ");
		System.out.println("1.java \n 2.DBMS\n 3.Networking");
		Scanner sc=new Scanner(System.in);
		int ops=sc.nextInt();
		System.out.println(ops);
		switch(ops){
		case 1:
			System.out.println(student.name+"is being interviewed on JAVA....");
			break;
		case 2:
			System.out.println(student.name+"is being interviewed on DBMS..");
			break;
		case 3: 
			System.out.println(student.name +"is being interviewed on NetWoring..");
			break;
		default:
			System.out.println("please enter the above option only");
		}
		}
		
		System.out.println("please go for HR round.. your score is being evaluated");
		Random r=new Random();
		
		technicalSubjectLevel=r.nextInt(10);
        System.out.println("your technical interview is "+technicalSubjectLevel);

		return technicalSubjectLevel ;
		
	}
}

