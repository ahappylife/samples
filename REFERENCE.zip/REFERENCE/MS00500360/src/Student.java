

public class Student {
      int id;
      String name;
      int marksInPercentage;
      int noOfBacklogs;
   
      
     



	public Student(int id2, String name2, int marksInPercentage2, int noOfBacklogs2) {
	
		this.id = id2;
		this.name = name2;
		this.marksInPercentage = marksInPercentage2;
		this.noOfBacklogs = noOfBacklogs2;

	}


	void studentDetails(){
    	 System.out.println("student details of "+name);
    	 System.out.println("--------------------------");
    	 System.out.println("student id "+id);
    	 System.out.println("student marks in percentage "+marksInPercentage);
    	 System.out.println("student name "+name);
    	 
    	  
      }



	

	

}
