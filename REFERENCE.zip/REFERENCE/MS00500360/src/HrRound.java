import java.util.Random;

public class HrRound {
	int softSkillsLevel;
	public int hrInterview(int writtenScore, Student student){
		
		if(writtenScore>50){
			Random r=new Random();
			
			 softSkillsLevel=r.nextInt(10);
			
		}
		else{
			System.out.println("sorry you are not cleared the round ");
		}
		System.out.println("your Hr interview score is "+ softSkillsLevel);
		return  softSkillsLevel;
		
	}
}
