
public class Company {
	String companyName;
	Float salaryOfferedInLPA;
	EligibilityCriteria eligibilityCriteria;
	WrittenTest writtenTest;
	TechnicalRound technicalRound;
	HrRound hrRound;
	public Company(String companyName2, float salaryOfferedInLPA2) {
		this.companyName = companyName2;
		this.salaryOfferedInLPA = salaryOfferedInLPA2;
		
	}


}
