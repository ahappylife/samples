
public class PlacementCell {
	Company company;
	boolean isSelected(int technicalScore,int hrScore){
		if(( technicalScore+hrScore)>10){
			
			return true;
		}
		return false;
		
	}

	public static void main(String[] args) {
		
		 Student s=new Student(101,"manju",85,1);
		 s.studentDetails();
		
		 
		 EligibilityCriteria ec=new EligibilityCriteria();
		 ec.minimumEligibility(s);
		 
		 WrittenTest wt=new WrittenTest();
		 wt.writtenTest(s);
		  
		 TechnicalRound tr=new TechnicalRound();
		 tr.technicalInterview(wt.marks,s);
		 HrRound hr=new HrRound();
		 hr.hrInterview(wt.marks, s);
		 PlacementCell pc=new PlacementCell();
		 pc.isSelected(tr.technicalSubjectLevel, hr.softSkillsLevel);
		 Company c=new Company("TechMahindra",3.25f);
		 System.out.println(s.name+"has completed all rounds of interview");
		 System.out.println("congrualtions!! you are now an employee of "+c.companyName);
         
	}

}
