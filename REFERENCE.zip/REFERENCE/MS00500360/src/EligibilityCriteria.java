
public class EligibilityCriteria {
	int requiredPercentage=80;
	int maxNoOfBacklogsAllowed=1;
	public static boolean selected;
	public boolean minimumEligibility(Student student){
		if((student.marksInPercentage>=requiredPercentage)&&(student.noOfBacklogs<= maxNoOfBacklogsAllowed)){
			selected=true;
			return selected;
		}
		return selected;
		
		
	}

}
