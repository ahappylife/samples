public class Waiter {
	  String ListItems[];
	public String[] getListItems() {
		return ListItems;
	}
	public void setListItems(String[] listItems) {
		ListItems = listItems;
	}
	void menu(){
		System.out.println("[1.Full meals --100, 2.veg biriyani--150, 3.veg Rice--50, 4.veg Palav--100, 5.veg Manchuria--50, 6.gobi Nudles--50, 7.chicken Biriyani--200, 8.chicken65--200, 9.chicken Curry--100, 10.chicken Manchuria--150]");
		String[] listItems=new String[10];
		listItems[0]="Full meals --100";
		listItems[1]="veg biriyani--150";
		listItems[2]="veg Rice--50";
		listItems[3]="veg Palav--100";
		listItems[4]="veg Manchuria--50";
		listItems[5]="gobi Nudles--50";
		listItems[6]="chicken Biriyani--200";
		listItems[7]="chicken65--200";
		listItems[8]="chicken Curry--100";
		listItems[9]="chicken Manchuria--150";
		
	   setListItems(listItems);
	  	}
	void placeOrderToChef(Order order,String VegRNonveg){
		System.out.println(" waiter has placed order to chef");
		if(VegRNonveg=="veg"){
			VegChef v=new VegChef();
			v.vegSection(order);
		}
		else
		{
			NonVegChef nvc=new NonVegChef();
			nvc.nonVegSection(order);
		}

		
	}
	
	
	


}
