import java.util.Scanner;

public class Customer {
	private String customerName;
	private int customerTableNumber;
	Order order;
	
	

	public Customer(String customerName) {
		super();
		this.customerName = customerName;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public int getCustomerTableNumber() {
		return customerTableNumber;
	}


	public void setCustomerTableNumber(int customerTableNumber) {
		this.customerTableNumber = customerTableNumber;
	}


	public Order getOrder() {
		return order;
	}


	public void setOrder(Order order) {
		this.order = order;
	}


	Order orderingItems(){
		
		Order o=new Order();
		Scanner in=new Scanner(System.in);
		System.out.println("Order Number  - " + Order.orderNum);
		System.out.println("Enter Number of Items To Be Ordered");
		o.noOfItems = in.nextInt();
		System.out.println("enter the numbers and their quantity one by one...");
		for(int i = 0;i<o.noOfItems;i++){
			
			for(int j=0;j<2;j++){
				
				o.Items[i][j]=in.nextInt();
				
			}
			System.out.println("-------------------------------------------");
			
		}
        
	   
		
		
		
		return o;
		
	}
	void eat(){
		System.out.println("Waiter brought items to customer");
		System.out.println(customerName +" is eating....");
		
		
	}


}
