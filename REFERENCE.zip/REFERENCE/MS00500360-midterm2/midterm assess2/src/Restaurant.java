
public class Restaurant {

	public static void main(String[] args) {
		Customer c=new Customer("Manju");
		System.out.println("hello"+c.getCustomerName()+"please select the item number ");
		Waiter w=new Waiter();
		w.menu();
		
		Order o=c.orderingItems();
		c.setOrder(o);
		int[][] l=o.getItems();
		for(int i=0;i<o.noOfItems;i++){
			if(l[i][0]<=6){
				w.placeOrderToChef(o, "veg");
				VegChef vc=new VegChef();
				vc.prepareOrder(o, "veg");
			}
			else{
				w.placeOrderToChef(o, "non-veg");
				NonVegChef nv=new NonVegChef();
				nv.prepareOrder(o, "non-veg");
			}
			
		}
		c.eat();
		Bill b=new Bill(o,0,1);
		b.generateBill(c, w);
				
		
		
		
	}

}
