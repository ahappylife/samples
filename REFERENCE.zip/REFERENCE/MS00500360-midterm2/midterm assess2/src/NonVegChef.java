
public class NonVegChef extends Chef {
	public void nonVegSection(Order order)
	{
	System.out.println("your order is reached non-veg section ");
	System.out.println("order number"+order.orderNum +"is getting ready please wait(non-veg)");
	System.out.println("order number"+order.orderNum+"is ready(non-veg)");
	
	}
}
