
public class VegChef extends Chef {
	public void vegSection(Order order){
		System.out.println("your order reached the veg section");
		System.out.println("order number"+order.orderNum +"is getting ready please wait(veg)");
		System.out.println("order number"+order.orderNum+"is ready(veg)");
       
		
	}
	

}
