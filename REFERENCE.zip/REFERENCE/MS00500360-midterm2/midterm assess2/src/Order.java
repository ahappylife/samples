import java.util.Scanner;

public class Order {
	static int orderNum;
    int Items[][]=new int[10][10];
    int noOfItems;
    
    

	public void setItems(int[][] items) {
		Items = items;
	}
	static{
		orderNum=0;
	}
	Order(){
		orderNum++;
	}

	

	public int[][] getItems() {
		// TODO Auto-generated method stub
		return Items;
	}
    }
    
    

