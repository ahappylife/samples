
public class Bill {
	Order order;
	 int bill;
	 int count;
	 static int TotalBill=0;
	 void generateBill(Customer c,Waiter w){
	     System.out.println("Dear Customer "+c.getCustomerName()+" your bill:");
	     System.out.println("INVOICE\n----------------------\nITEM\t\t\t\tQUANT\t\tBILL");
	     System.out.println("--------------------------------------------------------");
	     for(int i=0;i<count;i++){
	    	 String[] st=w.ListItems[order.Items[i][0]-1].split("--");
	    	 int amount=Integer.parseInt(st[1]);
	    	 bill=bill+order.Items[i][1]*amount;
	    	 System.out.println(st[0]+"\t\t\t"+order.Items[i][1]+"\t\t"+amount);
	    	 
	     }
	     System.out.println("-------------------------------------------------------");
	     TotalBill=bill;
	     System.out.println("Total Bill\t\t\t\t"+TotalBill);
	 }
	public Bill(Order order, int bill, int count) {
		super();
		this.order = order;
		this.bill = bill;
		this.count = order.noOfItems;
	}
	
	
}
