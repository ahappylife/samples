
public class Chef {
	void prepareOrder(Order order, String vegRnonVeg){
	  if(vegRnonVeg=="veg"){
		  
		  callWaiter("veg");
	  }
	  else{
		  
		  callWaiter("non-veg");
	  }
	}
	void callWaiter(String vegRnonVeg){
		if(vegRnonVeg=="veg"){
		System.out.println("vegChef to waiter: you can now deliver items to customer ");
		}
		else{
			System.out.println("non-vegChef to waiter: you can now deliver items to customer ");
			
		}
		System.out.println("--------------------------------------------------------------");
	}


}
