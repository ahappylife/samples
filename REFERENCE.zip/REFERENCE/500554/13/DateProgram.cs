﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication16
{
    class DateProgram
    {
        class Program
        {
            static void Main(string[] args)
            {
                DateTime date = new DateTime(1945, 8, 15);
                Console.WriteLine(date.ToString("dd'th' 'of' MMMM yyyy"));
                Console.WriteLine($"Date and Time:  {date}");
                DateTime presentDate = DateTime.Now;
                Console.WriteLine($"Date and Time:  {presentDate}");
                TimeSpan ts = presentDate - date;
                int differenceInDays = ts.Days;
                Console.WriteLine(" difference in days: ", differenceInDays);
                Console.WriteLine(" difference in mins : " + presentDate.Subtract(date).Minutes);
                Console.WriteLine(" difference in secs : " + presentDate.Subtract(date).Seconds);
                Console.ReadKey();
            }
        }
    }
}