﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Program
{
    class ConversionPgm
    {
        static void Main(string[] args)
        {

            int number = GetInput("Enter the choice");
            switch (number)
            {
                case 1:

                    Console.WriteLine("Dollar to Indian Rupee");
                    Double dollar, rupee;
                    Console.WriteLine("\n\nEnter the Dollar Amount :");
                    dollar = Double.Parse(Console.ReadLine());
                   
                    double value = 65.48;
                    rupee = dollar * value;
                    Console.WriteLine("{0} Dollar = {1} Indian Rupees", dollar, rupee);
                    break;

                case 2:
                    Console.WriteLine("Dollar to British Pound");
                    Double euro, pound;
                    Console.WriteLine("\n \nEnter the Euro Amount :");
                    euro = Double.Parse(Console.ReadLine());
                  
                    double val = 0.81;
                    pound = euro * val;
                    Console.WriteLine("{0} Euro = {1} British Pounds", euro, pound);
                    break;

            }
            Console.ReadLine();
        }
        private static int GetInput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;

                }
                else
                {
                    Console.WriteLine("Error Message");
                }
            }
            return val;
        }

        }
}