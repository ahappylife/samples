﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication17

{
    class BankProgram
    {
        static void Main(string[] args)
        {
            Bank b = new Bank();
            b.initvalues();

            Console.WriteLine("Enter the choice");
            int choice;
            int.TryParse(Console.ReadLine(),out choice);
            switch (choice)
            {

                case 1:
                    b.deposit();
                    break;
                case 2:
                    b.withdraw();
                    break;
            }
        }
    }

    class Bank
    {

        public string holdername;
        public int accnumber;
        public double balance;

        public void display()
        {
            Console.WriteLine("Holder name and balance {0} {1}", holdername, balance);
        }

        public void initvalues()
        {
           
            Console.WriteLine("Enter the name of account holder");
            holdername = Console.ReadLine();
            Console.WriteLine("Enter the account number");
            accnumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the amount");
            balance = Convert.ToInt32(Console.ReadLine());
            display();

        }


        public void deposit()
        {

            Console.WriteLine("Enter the account number");
            int holderaccnumber = Convert.ToInt32(Console.ReadLine());

            if (holderaccnumber == accnumber)
            {
                Console.WriteLine("Enter the amount to deposit");
                double amount;
                double.TryParse(Console.ReadLine(),out amount);
                balance = balance + amount;
            }

            else
            {
                Console.WriteLine("Invalid account number");

            }
            display();
            Console.ReadLine();
        }



        public void withdraw()
        {

            Console.WriteLine("Please enter the account number");
            int holderaccnumber = Convert.ToInt32(Console.ReadLine());

            if (holderaccnumber == accnumber)
            {
                Console.WriteLine("Enter the amount to withdraw");
                double amount;
                double.TryParse(Console.ReadLine(), out amount);
                balance = balance - amount;
            }

            else
            {
                Console.WriteLine("Invalid account number");

            }
            display();
            Console.ReadLine();
        }


        
    }
}
