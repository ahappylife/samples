﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication10
{
    class PrimePgm
    {
        static int IsPrime(int number)
        {
            int i;
            for (i = 1; i <= number; i++)
            {
                if (number % i == 0)
                {
                    return i;
                }
            }
            if (i == number)
            {
                return 1;
            }

        }



        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            int res = IsPrime(number);
            if (res == 0)
            {
                Console.WriteLine("TRUE {0}", number);

            }
            else
            {
                Console.WriteLine("FALSE {0}", number);
            }
            Console.ReadLine();
        }

         
    }

}
    

