﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class FactorialTable
    {

        static void Main(string[] args)
        {

            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            int i, fact = 1;
           
            for (i = 1; i <= number; i++)
            {
                fact = fact * i;
                Console.WriteLine($"Factorial of {i} is {fact}  ");
                
            }

            Console.ReadKey();
        }

        
    }
}
