﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    class SumOfDigit
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int number = GetInput("Enter the number");

            while (number != 0)
            {
               
                sum = sum + number % 10;
                number = number / 10;
            }

            Console.WriteLine($"The sum of a given digit is\n{sum}");
            Console.ReadKey();
        }

        //GetInput

        private static int GetInput(string message)
        {
            int val;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;

                }
                else
                {
                    Console.WriteLine("Error Message");
                }
            }
            return val;
        }


    }
}
