﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace productcaselet
{
    class Product
    {
        private int productCode;
        public int ProductCode
        {
            get { return productCode; }
            set { productCode = value; }
        }
        public string ProductName { get; set; }
        public int CategoryCode { get; set; }
        public static int ProductCount = 0;
        
        public void AddProduct(List<Product> p)
        {
            Console.WriteLine("enter Product Name");
            StringBuilder MyStringBuilder = new StringBuilder(ProductName);
            ProductName = Console.ReadLine();
            Console.WriteLine("Enter Product Code");
            ProductCode = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Category Code");
            CategoryCode = Convert.ToInt32(Console.ReadLine());
            ProductCount += 1;


            Console.WriteLine("\n *******************\n   Entered Successfully   \n*******************");
            p.Add(new Product() { ProductCode = ProductCode, ProductName = ProductName, CategoryCode = CategoryCode });

        }

        public void RemoveProduct(Product p)
        {
            try
            {
                if (ProductCount <= 0)
                {
                    throw new UnderflowException();
                }
                else
                {


                    p.ProductCode = Convert.ToInt32(Console.ReadLine());
                    p.CategoryCode = 0;
                    p.ProductCode = 0;
                    p.ProductName = null;
                    ProductCount -= 1;
                    Console.WriteLine("The product isRemoved ");
                }
            }

            catch (UnderflowException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public virtual void ModifyProduct(int pcode)
        {
            try
            {
                if (ProductCount <= 0)
                {
                    throw new UnderflowException();

                }
                else
                {
                    int a;
                    Console.WriteLine("Press\n1.To Change Name of Product\n2.To change Product code\n3.To change Category Code\n4.To Change all\n5.To Exit without Changing");
                    a = Convert.ToInt16(Console.ReadLine());
                    switch (a)
                    {
                        case 1:
                            Console.WriteLine("enter new product name");
                            ProductName = Console.ReadLine();
                            break;
                        case 2:
                            Console.WriteLine("enter new Product Code");
                            ProductCode = Convert.ToInt32(Console.ReadLine());
                            break;
                        case 3:
                            Console.WriteLine("enter new Category Code");
                            CategoryCode = Convert.ToInt32(Console.ReadLine());
                            break;
                        case 4:
                            Console.WriteLine("enter new ProductName\nProduct Code\nCategory Code");
                            ProductName = Console.ReadLine();
                            ProductCode = Convert.ToInt32(Console.ReadLine());

                            CategoryCode = Convert.ToInt32(Console.ReadLine());
                            break;
                        case 5:
                            Console.WriteLine("exiting . .. .. .. ..");
                            break;



                            Console.WriteLine("The modified details of product is:");
                            Console.WriteLine(ToString());
                    }
                }
            }

            catch (UnderflowException ex)
            {
                Console.WriteLine(ex.Message);

            }

        }



        public override string ToString()
        {
            return "ProductCode :" + "" + productCode + "," + "\n" + " ProductName:" + "" + ProductName + "," + "\n" + "CategoryCode:" + "" + CategoryCode;
        }
    }

}
