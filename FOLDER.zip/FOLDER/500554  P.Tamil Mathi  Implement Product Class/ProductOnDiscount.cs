﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace productcaselet
{
    class ProductOnDiscount : Product, IProduct
    {
        public double DiscountPercentage { get; set; }
        public int MinimumPickQuantity { get; set; }

        List<Product> p = new List<Product>();
        List<ProductOnDiscount> pd = new List<ProductOnDiscount>();



        public void AddProduct()
        {
           
            Console.WriteLine("Enter the Name of the Product ");
            StringBuilder MyStringBuilder = new StringBuilder(ProductName);
            ProductName = Console.ReadLine();

            //validation 

            Console.WriteLine("Enter the Product Code");
            string ProductCode = Console.ReadLine();
            Regex reg = new Regex(@"^([A-Z]{3}-[0-9]{3})+$");
            if (reg.IsMatch(ProductCode))
            {
                Console.WriteLine("Code is Valid");
            }
            else
            {
                Console.WriteLine("Enter Valid Code");
            }
            Console.ReadLine();

            Console.WriteLine("Enter the Product Category Code");
            CategoryCode = Convert.ToInt32(Console.ReadLine());
            ProductCount += 1;

        }
        
        public override void ModifyProduct(int pcode)
        {
            ProductOnDiscount p = new ProductOnDiscount();
            if (p.ProductCode == pcode)
            {
                int a;
                Console.WriteLine("1.To Change Name of Product");
                Console.WriteLine("2.To change Product code");
                Console.WriteLine("3.To change Category Code");
                Console.WriteLine("Exit");
                a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        Console.WriteLine("Enter Product name");
                        ProductName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Enter Product Code");
                        string ProductCode = (Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("Enter Category Code");
                        CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                 
                    case 4:
                        Console.WriteLine("Exit");
                        break;
                }
            }
        }
        public void ModifyProduct(string pName)
        {
            ProductOnDiscount p = new ProductOnDiscount();
            if (p.ProductName.Equals(pName))
            {
                int a;
                Console.WriteLine("1.To Change Name of Product");
                Console.WriteLine("2.To change Product code");
                Console.WriteLine("3.To change Category Code");
                Console.WriteLine("Exit");
                a = Convert.ToInt16(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        Console.WriteLine("Enter new product name");
                        p.ProductName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Enter new Product Code");
                        string ProductCode = (Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("Enter new Category Code");
                        p.CategoryCode = Convert.ToInt32(Console.ReadLine());
                        break;
                   
                    case 4:
                        Console.WriteLine("Exit");
                        break;
                }
            }
        }
        public void RemoveProduct(int pcode)
        {
            ProductOnDiscount p = new ProductOnDiscount();
            if (p.ProductCode == pcode)
            {
                p.CategoryCode = 0;
                p.ProductCode = 0;
                p.ProductName = null;
                ProductCount -= 1;
            }
        }
        public void RemoveProduct(string pname, int pcode)
        {

            ProductOnDiscount p = new ProductOnDiscount();
            if (p.ProductCode == pcode)
            {
                p.CategoryCode = 0;
                p.ProductCode = 0;
                p.ProductName = null;
                ProductCount -= 1;
            }
        }
        public int GetProductCode(string PName)
        {
            int pcode = 0;
            return pcode;
        }
        
        public double GetDiscountPercent(int pcode)
        {
            double perc = 1.0;

            Console.WriteLine("Discount Percent is:{0}", perc);
            return perc;
        }
        public string GetProductDesc(int pcode)
        {
            string pname = "";
            return pname;
        }
        public int GetCategoryCode(int pcode)
        {
            int Ccode = 0;
            return Ccode;
        }
        public double GetQuantityOnSale()
        {
            double d = 10.00;
            return d;
        }
        public override string ToString()
        {
            return ProductCode + "\n" + ProductName + "\n" + CategoryCode;
        }
    }
}
