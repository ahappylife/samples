﻿create table pack_grades(grade_id int primary key,
grade_name varchar(50) not null,
min_price money,max_price money)



create table sectors(sector_id int primary key,
sector_name varchar(50))

create table packages(pack_id int primary key,
speed int,
strt_date date,
monthly_payment int,
sector_id int foreign key references sectors(sector_id))

create table customers(Customer_id int primary key,
First_Name varchar(30) not null,
Last_Name varchar(30) not null,
Birth_Date date,
Join_Date date,
City varchar(30),
StateName varchar(50),
Street varchar(30),
main_phone_num varchar(15),
secondary_phone_num varchar(15),
fax varchar(15),
monthly_discount money,
pack_id int foreign key references packages(pack_id))




alter table packages
    alter column monthly_payment money

exec sp_columns pack_grades

alter table packages
    alter column speed decimal

exec sp_columns packages

INSERT pack_grades VALUES (1, 'Very Low', 0, 10)
INSERT pack_grades VALUES (2, 'Low', 11, 20)
INSERT pack_grades VALUES (3, 'Medium', 21, 40)
INSERT pack_grades VALUES (4, 'High', 41, 80)
INSERT pack_grades VALUES (5, 'Very High', 81, 150)

alter table packages
    alter column speed varchar(20)


INSERT packages VALUES(1,'750Kbps',CAST(0x5C2C0B00 AS Date),79,1)
INSERT packages VALUES(2,'750Kbps',CAST(0x8D2D0B00 AS Date),69,1)
INSERT packages VALUES(3,'750Kbps',CAST(0x092E0B00 AS Date),59,1)
INSERT packages VALUES(4,'750Kbps',CAST(0x05300B00 AS Date),49,1)
INSERT packages VALUES(5,'750Kbps',CAST(0xF9310B00 AS Date),39,1)
INSERT packages VALUES(6,'750Kbps',CAST(0x51320B00 AS Date),29,1)
INSERT packages VALUES(7,'750Kbps',CAST(0xA42B0B00 AS Date),69,2)
INSERT packages VALUES(8,'750Kbps',CAST(0x7D2D0B00 AS Date),59,2)
INSERT packages VALUES(9,'750Kbps',CAST(0x342F0B00 AS Date),49,2)
INSERT packages VALUES(10,'750Kbps',CAST(0x9C300B00 AS Date),39,2)
INSERT packages VALUES(11,'750Kbps',CAST(0x29320B00 AS Date),29,2)
INSERT packages VALUES(12,'750Kbps',CAST(0x2C330B00 AS Date),19,2)
INSERT packages VALUES(13,'1.5Mbps',CAST(0xBD2C0B00 AS Date),89,1)
INSERT packages VALUES(14,'1.5Mbps',CAST(0xB52E0B00 AS Date),79,1)
INSERT packages VALUES(15,'1.5Mbps',CAST(0xA2300B00 AS Date),69,1)
INSERT packages VALUES(16,'1.5Mbps',CAST(0x8F310B00 AS Date),59,1)
INSERT packages VALUES(17,'1.5Mbps',CAST(0x76320B00 AS Date),49,1)
INSERT packages VALUES(18,'1.5Mbps',CAST(0x3B2D0B00 AS Date),79,2)
INSERT packages VALUES(19,'1.5Mbps',CAST(0x3C2E0B00 AS Date),69,2)
INSERT packages VALUES(20,'1.5Mbps',CAST(0xA02F0B00 AS Date),59,2)
INSERT packages VALUES(21,'1.5Mbps',CAST(0x4A310B00 AS Date),49,2)
INSERT packages VALUES(22,'1.5Mbps',CAST(0x5F320B00 AS Date),39,2)
INSERT packages VALUES(23,'2.5Mbps',CAST(0x0C2E0B00 AS Date),99,1)
INSERT packages VALUES(24,'2.5Mbps',CAST(0xD82F0B00 AS Date),89,1)
INSERT packages VALUES(25,'2.5Mbps',CAST(0xC6310B00 AS Date),79,1)
INSERT packages VALUES(26,'2.5Mbps',CAST(0x09330B00 AS Date),69,1)
INSERT packages VALUES(27,'2.5Mbps',CAST(0x8B2E0B00 AS Date),89,2)
INSERT packages VALUES(28,'2.5Mbps',CAST(0x7C2F0B00 AS Date),79,2)
INSERT packages VALUES(29,'2.5Mbps',CAST(0xEC300B00 AS Date),69,2)
INSERT packages VALUES(30,'2.5Mbps',CAST(0x66320B00 AS Date),59,2)
INSERT packages VALUES(31,'5Mbps',CAST(0x55300B00 AS Date),109,1)
INSERT packages VALUES(32,'5Mbps',CAST(0xF6300B00 AS Date),99,1)
INSERT packages VALUES(33,'5Mbps',CAST(0xDF320B00 AS Date),89,1)
INSERT packages VALUES(34,'5Mbps',CAST(0xD1300B00 AS Date),99,2)
INSERT packages VALUES(35,'5Mbps',CAST(0x24320B00 AS Date),89,2)
INSERT packages VALUES(36,'5Mbps',CAST(0x5D330B00 AS Date),79,2)
INSERT packages VALUES(37,'10Mbps',CAST(0xE8300B00 AS Date),119,1)
INSERT packages VALUES(38,'10Mbps',CAST(0xAF320B00 AS Date),109,1)
INSERT packages VALUES(39,'10Mbps',CAST(0x2A320B00 AS Date),109,2)
INSERT packages VALUES(40,'10Mbps',CAST(0x5C320B00 AS Date),99,2)
INSERT packages VALUES(41,'12Mbps',CAST(0xB2330B00 AS Date),129,1)
INSERT packages VALUES(42,'12Mbps','2005-11-03',119,2)


INSERT sectors VALUES(1,'Private')
INSERT sectors VALUES(2,'Business')

INSERT customers VALUES(1,'Alvin','Smith','1962-06-27',CAST(0x812D0B00 AS Date),'NewYork','NewYork','5953HollisterAvenue','567.867.3945','936.228.9436','762.788.3400',CAST(28.00 AS Decimal(4,2)),18)
INSERT customers VALUES(2,'Jose','Jones','1968-01-17',CAST(0x12300B00 AS Date),'LosAngeles','California','4081HollisterAvenue','520.336.8373','939.115.6982','711.883.3345',CAST(12.00 AS Decimal(4,2)),31)
INSERT customers VALUES(3,'Amado','Taylor','1965-08-17',CAST(0x802C0B00 AS Date),'Chicago','Illinois','3402BroderickStreet','522.501.6331','976.113.3737','767.944.7131',NULL,7)
INSERT customers VALUES(4,'Stuart','Williams','1983-05-01',CAST(0xF32E0B00 AS Date),'Houston','Texas','5543JenningsStreet','530.339.4737','963.891.4185','756.186.3634',CAST(17.00 AS Decimal(4,2)),23)
INSERT customers VALUES(5,'Demarcus','Brown','1971-12-02',CAST(0xD62C0B00 AS Date),'Philadelphia','Pennsylvania','5321LagunaStreet','580.733.2184',NULL,'760.663.2046',CAST(11.00 AS Decimal(4,2)),13)
INSERT customers VALUES(6,'Mark','Davies','1970-09-01',CAST(0xAB310B00 AS Date),'Phoenix','Arizona','5868CameronWay','557.701.1366','919.345.5511',NULL,CAST(18.00 AS Decimal(4,2)),39)
INSERT customers VALUES(7,'Merlin','Evans','1962-04-13',CAST(0xD52B0B00 AS Date),'SanAntonio','Texas','8177BrannanStreet','542.753.9215','992.959.8999',NULL,CAST(23.00 AS Decimal(4,2)),1)
INSERT customers VALUES(8,'Elroy','Wilson','1963-01-28',CAST(0x19330B00 AS Date),'SanDiego','California','1873KeyAvenue','544.172.1347','985.345.8501',NULL,CAST(6.00 AS Decimal(4,2)),42)
INSERT customers VALUES(9,'Charles','Thomas','1960-05-13',CAST(0x44320B00 AS Date),'SanJose','California','9164ValenciaStreet','515.656.3047',NULL,'799.101.7626',CAST(29.00 AS Decimal(4,2)),37)
INSERT customers VALUES(10,'Rudolph','Roberts','1973-11-05',CAST(0x412C0B00 AS Date),'Jacksonville','Florida','6308GilbertStreet','549.569.1762','942.671.2496','729.973.1742',CAST(7.00 AS Decimal(4,2)),7)
INSERT customers VALUES(11,'Laurence','Johnson','1975-11-25',CAST(0xC62F0B00 AS Date),'Indianapolis','Indiana','7529McLarenAvenue','527.138.3311','916.219.9787',NULL,CAST(9.00 AS Decimal(4,2)),34)
INSERT customers VALUES(12,'Pasquale','Lewis','1969-05-24',CAST(0x162F0B00 AS Date),'Austin','Texas','1569ClevelandStreet','566.849.6722','983.706.4341',NULL,NULL,27)
INSERT customers VALUES(13,'Pat','Walker','1985-07-02',CAST(0x8D300B00 AS Date),'SanFrancisco','California','4687SloatBoulevard','582.885.8362','938.219.8802',NULL,NULL,31)
INSERT customers VALUES(14,'Harland','Robinson','1974-04-17',CAST(0xFD2F0B00 AS Date),'Columbus','Ohio','5390MontgomeryStreet','520.519.1795','944.392.2529','721.443.8826',CAST(30.00 AS Decimal(4,2)),31)
INSERT customers VALUES(15,'Herschel','Wood','1974-07-24',CAST(0xE9320B00 AS Date),'FortWorth','Texas','7842CorbettAvenue','588.826.5279','997.263.1636','779.791.4617',CAST(30.00 AS Decimal(4,2)),41)
INSERT customers VALUES(16,'Galen','Thompson','1964-12-08',CAST(0x902B0B00 AS Date),'Charlotte','NorthCarolina','5466FarragutAvenue','599.783.7133',NULL,'753.251.6433',CAST(16.00 AS Decimal(4,2)),1)
INSERT customers VALUES(17,'Brain','White','1978-02-13',CAST(0x1F300B00 AS Date),'Detroit','Michigan','3728IngersonStreet','561.654.2679','957.711.4041','794.811.7354',NULL,34)
INSERT customers VALUES(18,'Marcel','Watson','1978-10-12',CAST(0x452E0B00 AS Date),'ElPaso','Texas','9157LeidesdorffStreet','567.827.2421','937.806.4116','723.277.6166',CAST(28.00 AS Decimal(4,2)),23)
INSERT customers VALUES(19,'Lino','Jackson','1982-06-25',CAST(0x2E2E0B00 AS Date),'Memphis','Tennessee','4542McKinnonAvenue','557.460.8507','984.433.8202','792.908.7024',CAST(6.00 AS Decimal(4,2)),27)
INSERT customers VALUES(20,'Riley','Wright','1970-02-18',CAST(0x2B2B0B00 AS Date),'Boston','Massachusetts','4848VallejoStreet','541.661.3366','931.368.3046','737.625.7424',CAST(21.00 AS Decimal(4,2)),1)

--3
select * from customers

--4
select pack_id,speed,monthly_payment
from packages

--5
select Customer_id,First_Name,Last_Name,main_phone_num,secondary_phone_num,pack_id
from customers

--6
select First_Name,Last_Name,Join_Date,monthly_discount,(monthly_discount + .2) as monthly_discount_after_addition_of_twenty_percent,(monthly_discount - .2) as monthly_discount_after_reduction_of_twenty_percent
from customers

--7
select pack_id,speed,strt_date,monthly_payment,monthly_payment*12 as YearlyPayment
from packages

--8
select concat(First_name,' ',Last_Name) as FULL_NMAE, concat(main_phone_num,' ,',' ',secondary_phone_num) as CONTACT_DETAILS 
from customers

--9
select distinct City
from customers

--10
select distinct StateName
from customers

--11
select distinct City,StateName
from customers

--12
select concat(Last_Name,' ',StateName) as CUSTOMER_AND_SATE
from customers

--13
select First_Name as FN,Last_Name as LN,monthly_discount as DC,concat(city,' ',Street) as FULL_ADDRESS
from customers

--14
select distinct monthly_discount 
from customers

--15
select distinct pack_id
from customers

--16
select First_Name,Last_Name,pack_id
from customers
where Last_Name='King'

--17
select *
from packages
where speed='5Mbps'

--18
select First_Name,Last_Name,pack_id,monthly_discount
from customers
where monthly_discount<30

--19
select *
from customers
where Join_Date < '2007-01-01'

--20
select Customer_id,First_Name,StateName,City,pack_id
from customers
where pack_id in (21,28,14)

--21
select Customer_id,First_Name,StateName,City,pack_id
from customers
where pack_id not in (27,10,3)

--22
select Last_Name,main_phone_num,monthly_discount,pack_id
from customers
where Customer_id in (703,314,560)

--23
select First_Name,monthly_discount
from customers
where First_Name like '%e'

--24
select Last_Name,pack_id
from customers
where Last_Name like '_d%'

--25
select *
from customers
where (Last_Name like '%l%' or
       Last_Name like '%j%' or
	   Last_Name like '%h%')
	   order by monthly_discount desc

--26
select First_Name,Join_Date,monthly_discount,pack_id
from customers
where Last_Name not like '%a%'
order by pack_id

--27
select *
from customers
where pack_id is null

--28
select concat(First_Name,' ',Last_Name),monthly_discount
from customers
where monthly_discount not between 20 and 30

--29
select concat(First_Name,' ',Last_Name)as FULL_NAME,concat(main_phone_num,' ',Street) as CONTACTS,monthly_discount as DC
from customers
where monthly_discount between 11 and 27

--30
select *
from customers
where (City='New York' and monthly_discount between 30 and 40)
or
(pack_id not in (8,9,30) and Join_Date < '2007-01-01')

--31
select Last_Name,pack_id,Birth_Date
from customers
where Birth_Date between '2007-12-12' and '2010-04-17'

--32
select pack_id,Strt_date,speed
from packages
where strt_date <'2007-01-01'

--33
select pack_id,speed,sector_id
from packages
where sector_id=1

--34
select pack_id,speed,sector_id
from packages
where speed= '5Mbps' or  speed='10Mbps'

--35
select Last_Name,monthly_discount
from customers
where City='Orlando'

--36
select Last_Name,pack_id
from customers
where pack_id in (9,18)

select Last_Name,pack_id
from customers
where pack_id =9 or pack_id=18

--37
select First_Name,main_phone_num,secondary_phone_num
from customers
where secondary_phone_num is null

--38
select first_name,monthly_discount,pack_id
from customers
where monthly_discount is null

--39
select Customer_id,lower(First_Name),upper(Last_Name)
from customers
where Customer_id between 80 and 150

--40
select First_Name,Last_Name,concat(substring(First_Name,1,1),upper((substring(Last_Name,1,3))),'@mymail.com') as email_address
from customers

select First_Name,Last_Name,concat(substring(First_Name,1,1),upper((substring(Last_Name,len(Last_Name)-2,3))),'@mymail.com') as email_address
from customers


--41
select Last_Name,len(Last_Name)
from customers
where len(Last_Name)>9

--42
select First_Name,Last_Name,main_phone_num,replace(main_phone_num,'515','$$$')as new_phone_num
from customers

select First_Name,Last_Name,main_phone_num,concat(replace(left(main_phone_num,3),'515','$$$'),substring(main_phone_num,4,12))as new_phone_num
from customers

--43
select First_Name,monthly_discount,(monthly_discount+0.197),round(monthly_discount * 0.197,2),floor(monthly_discount * 0.197),ceiling(monthly_discount * 0.197)
from customers

--44
select  First_Name ,join_date,DATEADD(dd, -10 , join_date),DATEADD(mm , 1 , join_date),DATEDIFF(dd , join_date , getdate())
from customers 

--45
select First_Name,Birth_Date,DATEDIFF(yy,Birth_Date,getdate()) as age
from customers
where DATEDIFF(yy,Birth_Date,getdate()) > 50 

--46
select First_Name , Birth_Date
from customers
where month(Birth_Date) = month(getdate())
      AND
      day(Birth_date) = day(getdate())


--47
select First_Name,Join_Date,DATEDIFF(yy,Join_Date,getdate())
from customers
where DATEDIFF(yy,Join_Date,getdate())=5
  
--48
select First_Name +' ' + cast((Join_Date) AS VARCHAR(20)) as First_Name_Join_Date,
       Last_Name + ' ' + cast ((monthly_discount) AS VARCHAR(20)) as Last_Name_monthly_discount
       from customers   


--49
select  Last_Name,
        upper(StateName) + ' / ' + convert(varchar , Customer_id ,100 ) ,
        convert(varchar , Birth_Date , 103) + ' / ' + convert(varchar , join_date ,  103)
from customers
where substring(last_name , 1 , 1) IN ('D' , 'K')

--50
select First_Name,Last_Name,coalesce(Birth_Date,'N/A'),coalesce(main_phone_num,'N/A'),coalesce(secondary_phone_num,'N/A')
from customers
where pack_id=27

select First_Name,Last_Name,Birth_Date,coalesce(main_phone_num,'N/A'),coalesce(secondary_phone_num,'N/A')
from customers
where year(Birth_Date)=1972

--51
select first_name , last_name , monthly_discount ,
             case when monthly_discount BETWEEN 0 AND 10 then 'A'
                when monthly_discount BETWEEN 11 AND 20 then 'B'
                when monthly_discount BETWEEN 21 AND 30 then 'C'
                else 'D'
             end as 'Grades'
from customers

--52
select lower(Last_Name) as last_name
from customers

--53
select avg(monthly_discount) as monthly_discount
from customers

--54
select max(Last_Name) as last_name
from customers

--55
select count(pack_id) as internet_packages
from customers

--56
select count(*)
from customers

--57
select count(distinct(StateName))
from customers

--58
select count(distinct(pack_id))
from customers

--59
select count(fax) as fax_count
from customers
where fax is not null

--60
select (count(*) - count(fax)) as fax_count 
from customers

--61
select max(monthly_discount) as max_discount,min(monthly_discount) as min_discount,avg(monthly_discount) as avg_discount
from customers

--62
select StateName,count(*) as no_of_state
from customers
group by StateName

--63
select speed,avg(monthly_payment) as avg_monthly_payment
from packages
group by speed

--64
select StateName,count(distinct(City)) as distinct_state
from customers
group by StateName

--65
select sector_id,max(monthly_payment) as max_payment
from packages
group by sector_id


--66
select pack_id,avg(monthly_discount) as avg_monthly_discount
from customers
group by pack_id

select pack_id,avg(monthly_discount) as avg_monthly_discount
from customers
where pack_id in (22,13)

--67
select max(monthly_payment) as max_pay,min(monthly_payment) as min_pay,avg(monthly_payment) as avg_pay
from packages
group by speed

--68
select pack_id,count(pack_id) as no_of_customers
from customers
group by pack_id

select pack_id,monthly_discount,count(pack_id) as no_of_customers
from customers
where monthly_discount >20
group by pack_id,monthly_discount

select pack_id,count(pack_id) as no_of_customers
from customers
group by pack_id
having count(pack_id)>100


--69
select StateName,City,count(*) as no_of_customers
from customers
group by StateName,City

--70
select City,avg(monthly_discount) as avg_monthly_discount
from customers
group by City

select City,avg(monthly_discount) as avg_monthly_discount
from customers
where monthly_discount>20
group by City

--71
select StateName,min(monthly_discount) as min_discount
from customers
group by StateName

select StateName,min(monthly_discount) as min_discount
from customers
group by StateName
having min(monthly_discount)>10

--72
select speed,count(pack_id) as no_of_packages
from packages
group by speed
having count(pack_id)>8

--73
select c.First_Name,c.Last_Name,p.pack_id,p.speed
from customers c,packages p
where c.pack_id=p.pack_id


select c.First_Name,c.Last_Name,p.pack_id,p.speed
from customers c,packages p
where c.pack_id=p.pack_id
and (p.pack_id in (22,27))
order by c.Last_Name desc

--74
select p.pack_id,p.speed,p.monthly_payment,s.sector_Name
from sectors s,packages p
where s.sector_id=p.sector_id

select concat(c.First_Name,' ',c.Last_Name),p.pack_id,p.speed,p.monthly_payment,s.sector_name
from customers c,packages p,sectors s
where s.sector_id=p.sector_id
and (c.pack_id=p.pack_id)


select concat(c.First_Name,' ',c.Last_Name),p.pack_id,p.speed,p.monthly_payment,s.sector_name
from customers c 
join packages p
on (c.pack_id=p.pack_id)
join sectors s
on (s.sector_id=p.sector_id)
where s.sector_name='business'

--75
select concat(c.First_Name,' ',c.Last_Name),p.pack_id,p.speed,p.monthly_payment,s.sector_name
from customers c 
join packages p
on (c.pack_id=p.pack_id)
join sectors s
on (s.sector_id=p.sector_id)
where year(c.Join_Date)=2006
and s.sector_name='private'

--76
select p.pack_id,p.speed,p.monthly_payment,pg.grade_id
from packages p 
JOIN pack_grades pg
on  p.pack_id = pg.grade_id

--77
select concat(c.First_Name,' ',c.Last_Name),p.pack_id,p.speed,p.monthly_payment
from customers c 
inner join packages p
on (c.pack_id=p.pack_id)

select concat(c.First_Name,' ',c.Last_Name) as customer_name
from customers c 
left outer join packages p
on (c.pack_id=p.pack_id)

select concat(c.First_Name,' ',c.Last_Name) as customer_name
from customers c 
right outer join packages p
on (c.pack_id=p.pack_id)

select concat(c.First_Name,' ',c.Last_Name) as customer_name
from customers c 
full outer join packages p
on (c.pack_id=p.pack_id)


--78
select c.First_Name,c.Last_Name,c.pack_id
from customers c 
join customers c1
on (c.pack_id=c1.pack_id)
where c1.Last_Name = 'Taylor' AND c1.First_Name = 'Amado'

--79
select c.First_Name,c.Last_Name,c.pack_id,c1.monthly_discount
from customers c 
join customers c1
on (c.pack_id=c1.pack_id)
where  c1.Customer_id = 103
       AND c.monthly_discount < c1.monthly_discount

--or--

select First_Name , Last_Name ,pack_id,monthly_discount
from customers
where monthly_discount < (select monthly_discount 
						  from customers  
						  where customer_id = 170)

--80

select p1.pack_id , p1.speed
from packages p1 JOIN packages p2
on p2.pack_id = 10
AND p1.speed = p2.speed
 

 --or--
select pack_id,speed
from  packages
where speed= (select speed  
			  from  PACKAGES 
			  where pack_id=10)

--81
select c.First_Name,c.Last_Name,c.City,c1.StateName
from customers c 
join customers c1
on (c.pack_id=c1.pack_id)
where  c1.Customer_id = 170

--or--

select first_name , last_name , StateName, city
from customers
where StateName = (select StateName 
				   from customers 
				   where customer_id = 170)​


--82
select p.pack_id,p.speed,s.sector_id
from packages p
join
sectors s
on(p.sector_id=s.sector_id)
where pack_id=10

--or--
select pack_id,speed,sector_id
from packages 
where sector_id in(select sector_id
				   from sectors
				   where pack_id=10)

--83
select First_Name , Last_Name , Join_Date
from customers
where Join_Date > (select Join_Date 
					from customers 
					where customer_id = 540)


--or-- 

select c.First_Name , c.Last_Name , c1.Join_Date
from customers c 
join customers c1
on (c.pack_id=c1.pack_id)
where c.Join_Date < c1.Join_Date
and  c1.Customer_id = 540

--84
select first_name , last_name , join_date
from customers
where year(join_date) = (select year( join_date)
						 from customers 
						 where customer_id = 372)
						 AND  month(join_date) = (select month(join_date) 
												  from customers  
												  where customer_id = 372)
                    

--85
select First_Name,Last_Name,City,StateName,pack_id
from customers
where pack_id IN (select pack_id 
				  from packages 
				  where speed = '5Mbps')

--86
select pack_id,speed,strt_date
from packages
where year(strt_date) = (select year(strt_date) 
						 from packages 
						 where pack_id = 7)

--87
select First_Name,monthly_discount,pack_id,main_phone_num,secondary_phone_num
from customers
where pack_id in (select pack_id
				  from packages
				  where sector_id in (select sector_id
									  from sectors
									  where sector_name='business'))


--88
select First_Name,monthly_discount,pack_id
from customers
where pack_id IN (select  pack_id 
				  from packages
                  where monthly_payment >(select AVG(monthly_payment)  
				                          from packages))
				  
--89
select Customer_id,First_Name,City,StateName,birth_date,monthly_discount
from customers
where birth_date in (select birth_date 
					from customers 
					where customer_id = 179)
					AND monthly_discount >(select monthly_discount 
					                       from customers 
					                       where customer_id = 107)
					
--90
select * 
from packages 
where speed=(select speed 
			 from packages 
			 where pack_id=30)

--91
select pack_id,speed,monthly_payment
from PACKAGES
where monthly_payment>(select MAX(monthly_payment) 
					   from packages
					   where speed ='5Mbps')

--92
select pack_id,speed,monthly_payment
from packages
where monthly_payment>(select MIN(monthly_payment) 
					   from packages 
                       where speed ='5Mbps')​

--93
select pack_id,speed,monthly_payment
from packages
where monthly_payment<(select MIN(monthly_payment) 
					   from packages 
                       where speed ='5Mbps')​

--94
select first_name ,monthly_discount , pack_id
from customers
where monthly_discount < (select AVG(monthly_discount) 
						  from customers)
                          AND pack_id IN (select pack_id 
						  from customers 
						  where first_name = 'Kevin')

AND monthly_payment >(SELECT monthly_payment FROM packages WHERE pack_id = 7)				  