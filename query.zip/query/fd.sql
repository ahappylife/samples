use Northwind

go
create view customers_detail
as select orderid,c.customerid,employeeid,shipname,
shipcity,companyname,phone,country
from orders o inner join customers c on o.customerid=c.customerid
where employeeid=6 and orderid=11019


select * from customers_detail


BEGIN TRY
-----Try and create our table
CREATE TABLE test_table(
col1 int primary key
)
END TRY



BEGIN CATCH
DECLARE @ErrorNo int,
@Severity tinyint,
@State smallint,
@LineNo int,
@Message nvarchar(4000)
SELECT
@ErrorNo = ERROR_NUMBER(),
@Severity = ERROR_SEVERITY(),
@State = ERROR_STATE(),
@LineNo = ERROR_LINE(),
@Message = ERROR_MESSAGE()
IF @ErrorNo = 2714
print 'WARNING: Skipping CREATE table already exists'
ELSE
RAISERROR(@Message,16,1)
END CATCH




-- declaring cursor
declare @name varchar(20)
declare cDetail CURSOR FAST_FORWARD READ_ONLY
FOR SELECT FirstName
from Employees

--open cursor
open cdetail

--prime the cursor
fetch cDetail into @name
print @name
while @@FETCH_STATUS=0

   begin
    print @name
    fetch cDetail into @name
   end

--close the cursor
close cDetail

--deallocate the cursor
deallocate cDetail



