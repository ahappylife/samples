select * from DimEmployee
order by EmployeeNationalIDAlternateKey

select *
from DimEmployee
where substring('HireDate',8,2)=81