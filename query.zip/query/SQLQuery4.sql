INSERT INTO c
VALUES (1,'Groceries')

drop table c

create table c(cid int not null)

insert into c values(1)


insert into c values (4)