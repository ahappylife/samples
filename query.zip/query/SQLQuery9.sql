



create database pgmtwo

create table empl(id int not null identity primary key,name varchar(20) not null)

/*adding new column*/

alter table empl
add email varchar(60) not null

alter table empl drop column name

drop table empl