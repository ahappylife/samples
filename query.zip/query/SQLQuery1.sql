create database ca
create table cate
(
catId int not null identity primary key,
catName varchar(40) not null
)

create table prod
(
prodId int not null identity primary key,
pName varchar(20) not null,
proQuan int not null
)



INSERT INTO c
VALUES (1,'Groceries')

insert into c
values (1,'cosmetics'),(2,'Hardware'),(3,'Fruits')


insert into p
values (1,'Rice',5),(2,'plate',5),(5,'choco',4)


