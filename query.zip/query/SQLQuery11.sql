create database category
create table categories
(
catId int not null identity primary key,
catName varchar(40) not null
)

create table products
(
prodId int not null identity primary key,
pName varchar(20) not null,
proQuan int not null
)