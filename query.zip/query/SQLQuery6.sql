select p.ProdID
from product p,cust c
where ProdQuantity>3;