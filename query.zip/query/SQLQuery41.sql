create database AdventureWorksDW2012

on primary
(
filename=N'D:\New folder\AdventureWorksDW2012_Data.mdf'
)
for
attach_rebuild_log