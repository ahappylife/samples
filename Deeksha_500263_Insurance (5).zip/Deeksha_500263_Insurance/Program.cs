﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePolicy
{
        abstract class InsurancePolicyEssentials
        {
            public InsurancePolicyEssentials()
            {

            }

            public string PolicyName
            {
                get
                {
                    return policyname;
                }
            }

            public string CustomerName;

            public int amount;

            public int years;

            public DateTime DateofInsurance;

            public DateTime MaturityDateofThePolicy;

            public int MaxCoverageLimit;

            public string policyname;

            public abstract void AddNewCustomer();


            public void RemoveCustomer(InsurancePolicyEssentials a)
            {
                a.CustomerName = null;
                a.amount = 0;

            }
            public void RemoveCustomer(InsurancePolicyEssentials b, int years)
            {
                b.CustomerName = null;
                b.amount = 0;
            }
            ~InsurancePolicyEssentials()
            {
                Console.WriteLine("Destructor is called");
            }

            public abstract void EditCustomerDetails();


            public virtual void GetPolicyDetails()
            {
                Console.WriteLine(PolicyName);
                Console.WriteLine(CustomerName);
                Console.WriteLine(DateofInsurance);
                Console.WriteLine(MaturityDateofThePolicy);
            }
        }

        interface IGetInstallmentDetails
        {
            void GetYearlyInstallmentDetails();
            void GetHalfYearlyInstallmentDetails();
            void MonthlyInstallmentDetails();
        }

        class InsuranceForIndividuals : InsurancePolicyEssentials, IGetInstallmentDetails
        {
            public int ROI { get; set; }

            public override void GetPolicyDetails()
            {

            Console.WriteLine($"PolicyName= {PolicyName}");
            Console.WriteLine($"CustomerName= {CustomerName}");
            Console.WriteLine($"Amount= {amount}");
            Console.WriteLine($"Number of years= {years}");
            Console.WriteLine($"Date of insurance= {DateofInsurance}");
            Console.WriteLine($"Maturity date of the policy= {MaturityDateofThePolicy}");
            Console.WriteLine($"Maximum coverage limit= {MaxCoverageLimit}");
        }
            public override void AddNewCustomer()
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Enter policy name: ");
                policyname = Console.ReadLine();
                Console.WriteLine("Enter customer name: ");
                CustomerName = Console.ReadLine();
                Console.WriteLine("Enter policy amount: ");
                amount = Convert.ToInt32(Console.ReadLine());
                years = 5;
                DateofInsurance = DateTime.Today;
                MaturityDateofThePolicy = DateTime.Today.AddYears(4);
                MaxCoverageLimit = 40000000;

            }
            public override void EditCustomerDetails()
            {
              Console.BackgroundColor = ConsoleColor.White;
              Console.ForegroundColor = ConsoleColor.Black;
              Console.WriteLine("Enter\n1.to change name of customer\n2.to change policy amount\n3.to change no.of plan years");
              Console.ResetColor();
              int A = Convert.ToInt16(Console.ReadLine());
                switch (A)
                {
                    case 1:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Enter new name: ");
                        CustomerName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Enter new policy amount: ");
                        int c = Convert.ToInt32(Console.ReadLine());
                        if (c <= MaxCoverageLimit)
                            amount = c;
                        break;
                    case 3:
                        Console.WriteLine("Enter new number of years: ");
                        years = Convert.ToInt32(Console.ReadLine());
                        break;
                }


            }
            public void ExtraFeatures()
            {
                Console.WriteLine("Rate of interest is 2 % per year!");
                Console.WriteLine("Maturity date is 4 years!");
                Console.WriteLine("Policy amount is Rs.500 only!");

            }
            public void GetYearlyInstallmentDetails()
            {
                ROI = 2;
                double am;
                am = amount;
                am += am * 0.01;
                Console.WriteLine("Yearly installment cost is " + am);
              
            }

            public void GetHalfYearlyInstallmentDetails()
            {
                ROI = 2;
                double am;
                am = amount / 6;
                am += am * 0.02;
                Console.WriteLine("Half yearly installment cost is " + am);
              
            }
            public void MonthlyInstallmentDetails()
            {
                ROI = 2;
                double am;
                am = amount / 12;
                am += am * 0.02;
                Console.WriteLine("Monthly installment cost is " + am);
            }
        }

        class InsuranceForFamily : InsurancePolicyEssentials, IGetInstallmentDetails
        {
            public int ROI { get; set; }

            public int NoOfPeopleCovered { get; set; }

            public int MaxNoOfPeopleCovered { get { return temp; } }

            int temp = 5;

            public override void AddNewCustomer()
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Enter policy name:");
                policyname = Console.ReadLine();
                Console.WriteLine("Enter customer name:");
                CustomerName = Console.ReadLine();
                Console.WriteLine("Enter policy amount:");
                amount = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter number of people to be covered:");
                int a = Convert.ToInt16(Console.ReadLine());
                try
                {
                    if (a >= MaxNoOfPeopleCovered)
                        throw (new MaxNoOfPepException());
                    else
                        NoOfPeopleCovered = a;
                }
                catch (MaxNoOfPepException e)
                {
                    Console.WriteLine(e.Message);
                }
                years = 3;
                DateofInsurance = DateTime.Today;
                MaturityDateofThePolicy = DateTime.Today.AddYears(4);
                MaxCoverageLimit = 60000000;

            }

            public override void GetPolicyDetails()
            {
                Console.WriteLine($"PolicyName= {PolicyName}");
                Console.WriteLine($"CustomerName= {CustomerName}");
                Console.WriteLine($"Amount= {amount}");
                Console.WriteLine($"Number of years= {years}");
                Console.WriteLine($"Date of insurance= {DateofInsurance}");
                Console.WriteLine($"Maturity date of the policy= {MaturityDateofThePolicy}");
                Console.WriteLine($"Maximum coverage limit= {MaxCoverageLimit}");

            }
            public override void EditCustomerDetails()
            {
                Console.BackgroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("Enter\n1.to change name of customer\n2.to change policy amount\n3.to change no.of plan years\n4.to change no of members");
                Console.ResetColor();
                int A = Convert.ToInt16(Console.ReadLine());
                switch (A)
                {
                    case 1:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Enter new name:");
                        CustomerName = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Enter new policy amount:");
                        int c = Convert.ToInt32(Console.ReadLine());
                        if (c <= MaxCoverageLimit)
                            amount = c;
                        break;
                    case 3:
                        Console.WriteLine("Enter new number of years: ");
                        years = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("Enter number of people to be covered:");
                        int a1 = Convert.ToInt16(Console.ReadLine());
                        try
                        {
                            if (a1 >= MaxNoOfPeopleCovered)
                                throw (new MaxNoOfPepException());
                            else
                                NoOfPeopleCovered = a1;
                        }
                        catch (MaxNoOfPepException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                }
            }
            public void ExtraFeatures()
            {
                Console.WriteLine("Rate of interest is 3 % per year for another policy by one of the family member!");
                Console.WriteLine("Maturity date can be extended to another  3 years!");
                Console.WriteLine("Policy amount is Rs.1000 only!");
            }

            public void GetYearlyInstallmentDetails()
            {
                ROI = 2;
                double am;
                am = amount;
                am += am * 0.01;
                Console.WriteLine("Yearly installment cost is " + am);
            }

            public void GetHalfYearlyInstallmentDetails()
            {
                ROI = 2;
                double am;
                am = amount / 6;
                am += am * 0.02;
                Console.WriteLine("Half yearly installment cost is " + am);
            }
            public void MonthlyInstallmentDetails()
            {
                ROI = 2;
                double am;
                am = amount / 12;
                am += am * 0.02;
                Console.WriteLine("Monthly installment cost is " + am);
                Console.ResetColor();
            }
        }

        class MaxNoOfPepException : ApplicationException
        {

            public override string Message
            {
                get
                {
                    return " MaxNoOfPeopleCovered Exception";
                }
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                List<InsurancePolicyEssentials> pi = new List<InsurancePolicyEssentials>();

                InsuranceForIndividuals i = new InsuranceForIndividuals();
                InsuranceForFamily IF = new InsuranceForFamily();
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("^^^^^^^^^^^^^WELCOME TO LIFE INSURANCE CORPORATION^^^^^^^^^^^^^\n");

                while (true)
                {
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("1.Insurance for Individual\n2.Insurance for Family\n3.Exit");
                    Console.ResetColor();
                    int A = Convert.ToInt16(Console.ReadLine());
                    switch (A)
                    {

                        case 1:
                            Console.BackgroundColor = ConsoleColor.White;
                            Console.ForegroundColor = ConsoleColor.Black;
                            Console.WriteLine("1.To Add new Customer\n2.To Edit Customer Details\n3.To get Policy Details\n4.To remove Customer");
                            Console.ResetColor();
                            int B = Convert.ToInt16(Console.ReadLine());
                            switch (B)
                            {
                                case 1:
                                    i.AddNewCustomer();
                                    pi.Add(i);
                                    break;
                                case 2:
                                    i.EditCustomerDetails();
                                    break;
                                case 3:
                                    foreach (InsuranceForIndividuals i1 in pi)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Yellow;
                                        Console.WriteLine("Enter customer name:");
                                        string name = Console.ReadLine();
                                        if (i.CustomerName.Equals(name))
                                        {
                                            i.GetPolicyDetails();
                                            i.GetYearlyInstallmentDetails();
                                            i.GetHalfYearlyInstallmentDetails();
                                            i.MonthlyInstallmentDetails();
                                        }
                                        else
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine("Sorry, no customer name found!");
                                            Console.ResetColor();
                                            Console.ForegroundColor = ConsoleColor.Yellow;
                                            Console.WriteLine("Enter y to add new customer or n to exit.");
                                            char n = Convert.ToChar(Console.ReadLine());
                                            if (n.Equals('y') || n.Equals('Y'))
                                                i.AddNewCustomer();
                                            else
                                                break;
                                        }
                                    }
                                    break;
                                case 4:
                                    if ((i.MaturityDateofThePolicy.Year - DateTime.Today.Year) != 0)
                                        i.RemoveCustomer(i, i.years);
                                    else
                                        i.RemoveCustomer(i);
                                    break;
                            }
                            break;
                        case 2:
                            Console.BackgroundColor = ConsoleColor.White;
                            Console.ForegroundColor = ConsoleColor.Black;
                            Console.WriteLine("1.To Add new Customer\n2.To Edit Customer Details\n3.To get Policy Details\n4.To remove Customer");
                            Console.ResetColor();
                            int C = Convert.ToInt16(Console.ReadLine());
                            switch (C)
                            {
                                case 1:
                                    IF.AddNewCustomer();
                                    pi.Add(i);
                                    break;
                                case 2:
                                    IF.EditCustomerDetails();
                                    break;
                                case 3:
                                    foreach (InsuranceForFamily i1 in pi)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Yellow;
                                        Console.WriteLine("Enter customer name:");
                                        string nam = Console.ReadLine();
                                        if (IF.CustomerName.Equals(nam))
                                        {

                                            IF.GetPolicyDetails();
                                            IF.GetYearlyInstallmentDetails();
                                            IF.GetHalfYearlyInstallmentDetails();
                                            IF.MonthlyInstallmentDetails();
                                        }
                                        else
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine("Sorry,no customer name found!");
                                            Console.ForegroundColor = ConsoleColor.Yellow;
                                            Console.WriteLine("Enter y to add new customer or n to exit.");
                                            char n = Convert.ToChar(Console.ReadLine());
                                            if (n.Equals('y') || n.Equals('Y'))
                                                IF.AddNewCustomer();
                                            else
                                                break;
                                        }

                                    }
                                    break;
                                case 4:
                                    if ((IF.MaturityDateofThePolicy.Year - DateTime.Today.Year) != 0)
                                        IF.RemoveCustomer(IF, IF.years);
                                    else
                                        IF.RemoveCustomer(IF);
                                    break;
                            }
                            break;
                        case 3: break;
                    }
                    Console.WriteLine("Enter y to continue or n to exit.");
                    Console.ResetColor();
                    char n1 = Convert.ToChar(Console.ReadLine());
                    if (n1.Equals('y') || n1.Equals('Y'))
                        continue;
                    else
                        break;
                }
            }
        }
    }



